<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Filemanager</title>

  <!-- jQuery / jQuery UI -->
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>

  <!-- jQuery Touch Punch - Enable Touch Drag and Drop -->
  <script src="js/vendor/jquery.touch-punch.min.js"></script>

  <!-- jQuery.Shapeshift -->
  <script src="js/jquery.shapeshift.min.js"></script>

  <!-- CSS -->
  <style>
    .container {
      position: relative;
    }

    .container > div {
      background: #AAA;
      position: absolute;
      width: 200px;
      z-index: 10;
    }

    .container > div > img {
      max-width: 200px;
    }

    .container > .ss-placeholder-child {
      background: transparent;
      border: 1px dashed blue;
    }
  </style>

  <!-- Javascript -->
  <script>
    $(document).ready(function() {
      $(".container").shapeshift({
        minColumns: 1
      });
    });
    $(document).on("click","img",function(){
      if($(this).attr("data-type") == "image"){
        if($(this).attr("data-opened") == "false"){
          $(this).attr("data-opened","true");
          $(this).parent('div').css("width", "auto");
          $(this).parent('div').css("z-index", "100");
          $(this).css("max-width", "none");
        } else {
          $(this).attr("data-opened","false");
          $(this).parent('div').css("width", "200px");
          $(this).parent('div').css("z-index", "10");
          $(this).css("max-width", "200px");
        }
      } else {
        location.replace("?path="+$(this).attr("data-path"));
      }
    });
  </script>
</head>
<body>
  <div class="container">
<?php
if(isset($_GET['path'])){
  $dir = $_GET['path'];
} else {
  $dir = "images";
}

if (is_dir($dir)) {
  if ($dh = opendir($dir."/")) {
    if($dir != "images"){
      $sub_dirs = explode("/",$dir);
      unset($sub_dirs[count($sub_dirs)-1]);
      $sub_dirs = implode("/",$sub_dirs);
      echo "<div><img src='dir.jpg' data-type='dir' data-opened='false' data-path='".$sub_dirs."' /></div>";
    }
      while (($file = readdir($dh)) !== false) {
        if(($file != ".")&&($file != "..")){
          $type = filetype($dir ."/" . $file);
          echo "<div>";
          if($type == 'dir'){
            echo "<img src='dir.jpg' data-type='dir' data-opened='false' data-path='".$dir."/".$file."' />";
          } else {
            echo "<img src='".$dir."/".$file."' data-type='image' data-opened='false' />";
          }
          echo "</div>";
        }
          //print "Файл: $file : тип: " . filetype($dir . $file) . "\n";
      }
      closedir($dh);
  }
}
?>
</div>
</body>
</html>
