<?php

namespace App\Modules\User\Models;

use ScoutElastic\IndexConfigurator;
use ScoutElastic\Migratable;

class FacebookAdIndexConfigurator extends IndexConfigurator
{
    use Migratable;

    protected $name = 'facebook_ad';  
    /**
     * @var array
     */
    protected $settings = [
        //
    ];
}