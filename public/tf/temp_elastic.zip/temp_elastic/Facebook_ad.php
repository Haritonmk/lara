<?php

namespace App\Modules\User\Models;

use App\Modules\User\Models\Search_mix;
use Illuminate\Database\Eloquent\Model;
use DB;
use App\Modules\User\Models;
use Elasticsearch\Client;
use Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Log;
use App\Search\Searchable;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

use Mockery\CountValidator\Exception;



class Facebook_ad extends Model
{
    use Searchable;

    /**
     * @var string
     */
    protected $indexConfigurator = FacebookAdIndexConfigurator::class;


    public function searchableAs()
    {
        return 'doc';
    }

    public function toSearchableArray()
    {
        $array = $this->toArray();

        return $array;
    }

    /**
     * @var array
     */
    protected $searchRules = [
        //
    ];

    /**
     * @var array
     */
    protected $mapping = [
        "properties" => [
            "ad_id" => [
                "type" => "long"
            ],
            "ad_position" => [
                "type" => "text",
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 256
                    ]
                ]
            ],
            "affiliate_ad" => [
                "type" => "long"
            ],
            "call_to_action_id" => [
                "type" => "long"
            ],
            "category_id" => [
                "type" => "long"
            ],
            "comments" => [
                "type" => "long"
            ],
            "country_id" => [
                "type" => "long"
            ],
            "country_only_id" => [
                "type" => "long"
            ],
            "created_date" => [
                "type" => "date",
                "format" => "yyyy-MM-dd HH:mm:ss"
            ],
            "days_running" => [
                "type" => "long"
            ],
            "default_ad_url_id" => [
                "type" => "long"
            ],
            "default_analytics_id" => [
                "type" => "long"
            ],
            "default_variant_id" => [
                "type" => "long"
            ],
            "destination_scraper_status" => [
                "type" => "long"
            ],
            "discoverer_user_id" => [
                "type" => "long"
            ],
            "domain_id" => [
                "type" => "long"
            ],
            "first_seen" => [
                "type" => "date",
                "format" => "yyyy-MM-dd HH:mm:ss"
            ],
            "hits" => [
                "type" => "long"
            ],
            "id" => [
                "type" => "long"
            ],
            "l_c_s_status" => [
                "type" => "long"
            ],
            "l_c_s_updated_date" => [
                "type" => "date",
                "format" => "yyyy-MM-dd HH:mm:ss"
            ],
            "language_id" => [
                "type" => "long"
            ],
            "last_seen" => [
                "type" => "date",//_hour_minute_second
                "format" => "yyyy-MM-dd HH:mm:ss"
            ],
            "likes" => [
                "type" => "long"
            ],
            "lower_age_seen" => [
                "type" => "long"
            ],
            "platform" => [
                "type" => "long"
            ],
            "post_date" => [
                "type" => "date",
                "format" => "yyyy-MM-dd HH:mm:ss",
                "null_value" => "NULL"
            ],
            "post_owner_id" => [
                "type" => "long"
            ],
            "post_owner_updated" => [
                "type" => "long"
            ],
            "redirect_destination_url_source" => [
                "type" => "long"
            ],
            "reward_status" => [
                "type" => "long"
            ],
            "shares" => [
                "type" => "long"
            ],
            "source" => [
                "type" => "text",
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 256
                    ]
                ]
            ],
            "status" => [
                "type" => "long"
            ],
            "type" => [
                "type" => "text",
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 256
                    ]
                ]
            ],
            "updated_date" => [
                "type" => "date",
                "format" => "yyyy-MM-dd HH:mm:ss"
            ],
            "upper_age_seen" => [
                "type" => "long"
            ],
            "variants_count" => [
                "type" => "long"
            ],
            "target_country_status" => [
                "type" => "long"
            ],
            "targeted_country" => [
                "type" => "text",
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 256
                    ]
                ]
            ]
        ]
    ];

    private static $_instance = null;

    protected $table = 'facebook_ad';
    protected $fillable = ['*'];
    public $timestamps = false;

    public static function getInstance()
    {
        if (!is_object(self::$_instance))  //or if( is_null(self::$_instance) ) or if( self::$_instance == null )
            self::$_instance = new Facebook_ad();
        return self::$_instance;
    }

    public function getAd($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
//            return json_encode($selectedColumns);
//            return json_encode($where);

            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
                    ->get();
//                    ->toSql();
//                return json_encode($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }
    public function getAdgroup($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
                    ->groupby(DB::raw("date(created_date)"))
                    ->get();
//                return $result;
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getAdsForSpecifiedUsers($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip)
    {

        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();

        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {
                    $getAdDataResp = $this->formatSearchQuery($where, 'Ad data found by getAdsForSpecifiedUsers.');
//                    return json_decode(json_encode($getAdDataResp),true);
                    $triage_resp = json_decode($getAdDataResp, true);
                    if ($triage_resp["data"] == null) {
                        $triage_resp["code"] = 400;
                        $triage_resp["data"] = null;
                        return $triage_resp;
                    }
                    if (isset($where['version'])) {
                        $ids_sorted_with_skip_take = $triage_resp["data"];
                    } else if (isset($where['selected_user'])) {
                        $ids_sorted_with_skip_take = $triage_resp["data"];
                    } else {
                        $ids_sorted_with_skip_take = array_column($triage_resp["data"], "facebook_ad.id");
                    }
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
//                    return json_encode($clause4DeveloperId);
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') ', 'bindParams' => [$ids_sorted_with_skip_take]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByField($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);

                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $returnData->code = 400;
                    $returnData->message = "ES is not enabled ";
                    $returnData->data = null;
                }

            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

//     ---------------------------------Old code----------------------------------------

//        if (func_num_args() > 0) {
//            $where = func_get_arg(0);
//            try {
//                $result = DB::table($this->table)
//                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
//                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
//                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
//                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
//                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
//                    ->leftjoin('facebook_ad_users', 'facebook_ad.id', '=','facebook_ad_users.facebook_ad_id')
//                    ->select($selectedColumns)
//                    ->orderBy($order_column, $order_by)
//                    ->skip($skip)
//                    ->take($take)
////                    ->toSql();
//                    ->get();
//                $query = getenv("DEBUG_MODE")==1 ? DB::getQueryLog() : "";
////                $query = (DB::getQueryLog());
//                $data = (json_decode(json_encode($result), true));
//                if (isset($data[0])) {
//                    $returnData->code = 200;
//                    $returnData->message = 'Ad data found getAdsForSpecifiedUsers.';
//                    $returnData->data = $result;
//                } else {
//                    $returnData->code = 400;
//                    $returnData->message = 'No Ad data found by getAdsForSpecifiedUsers.';
//                    $returnData->data = null;
//                }
//            } catch (\Exception $e) {
//                $returnData->code = 401;
//                $returnData->message = $e->getMessage();
//                $returnData->data = null;
//            }
//
//            if(getenv("DEBUG_MODE")==1){
//                $returnData->query = $query ;
//            }
////            $returnData->query = $query ;
//            return json_encode($returnData);
//        }

    }

    public function getLatestAds($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad_post_owners.id', '=', 'facebook_ad.post_owner_id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('facebook_ad_image_video', 'facebook_ad_image_video.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad_variants.id', '=', 'facebook_ad.default_variant_id')
//                    ->leftjoin('facebook_call_to_actions', 'facebook_call_to_actions.id', '=', 'facebook_ad.call_to_action_id')
//                    ->leftjoin('facebook_users', 'facebook_users.id', '=', 'facebook_ad.discoverer_user_id')
//                    ->leftjoin('facebook_ad_countries', 'facebook_ad_countries.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->orderby("facebook_ad.likes", "desc")
                    ->take(10)
                    ->select($selectedColumns)
                    ->get();
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getOneAd($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
                    ->take(1)
                    ->get();
//                return $result;
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function updateFacebookAdwhere()
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $data = func_get_arg(0);
            $where = func_get_arg(1);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                if ($result == 0) {
                    $returnData->code = 400;
                    $returnData->message = "data not updated";
                    $returnData->data = null;
                }
                if ($result == 1) {
//                        dd(1);
                    $returnData->code = 200;
                    $returnData->message = "data updated successfully";
                    $returnData->data = $result;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            return json_encode($returnData);
        } else {
            throw new Exception('Argument Not Passed');
        }
    }

    public function deleteFacebookAdwhere()
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->delete();
                if ($result > 0) {
                    $returnData->code = 200;
                    $returnData->message = "data deleted successfully";
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = "data not deleted";
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
        }
        return json_encode($returnData);
    }

    public function insertFacebookAd($data)
    {

        $returnData = new \stdClass();

        try {
            $result = DB::table($this->table)
                ->insertGetId($data);

            if ($result > 0) {
                $returnData->code = 200;
                $returnData->message = "data inserted successfully";
                $returnData->data = $result;
            } else {
                $returnData->code = 400;
                $returnData->message = "data not inserted";
                $returnData->data = null;
            }
        } catch (\Exception $e) {
            $returnData->code = 401;
            $returnData->message = $e->getMessage();
            $returnData->data = null;
        }
//        $returnData['data'] = $result;
        return json_encode($returnData);
    }

    public function getFacebookAdCountwhere($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
//            dd($where);
            $result = DB::table($this->table)
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($selectedColumns)
                ->count();

            $data = (json_decode(json_encode($result), true));

            if (isset($data[0])) {
                $returnData->code = 200;
                $returnData->message = 'FacebookAd details.';
            } else {
                $returnData->code = 400;
                $returnData->message = 'No data found.';
            }
            $returnData->data = $result;

        }
        return json_encode($returnData);
    }

    //raushan(01-02-2018): for getting the ads based on advertiser,key,domain for guest page
    public function getJoinedAds($where, $selectedColumns, $order_column, $order_by, $take, $skip)
    {
        if (func_num_args() > 0) {
            try {
                return DB::table($this->table)
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad_post_owners.id', '=', 'facebook_ad.post_owner_id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad_image_video.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad_variants.id', '=', 'facebook_ad.default_variant_id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_call_to_actions.id', '=', 'facebook_ad.call_to_action_id')
                    ->leftjoin('facebook_users', 'facebook_users.id', '=', 'facebook_ad.discoverer_user_id')
                    ->leftjoin('facebook_ad_countries', 'facebook_ad_countries.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->take($take)
                    ->skip($skip)
                    ->get();
            } catch (\Exception $e) {
                dd($e->getMessage());
            }
        } else {
            throw new \Exception("Arguments not passed");
        }
    }

    //subhajit getads for filter and lander properties part
    public function getAdsByFL($where, $selectedColumns, $order_column, $order_by, $take, $skip)
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            try {
                $result = $result = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad_image_video.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_call_to_actions.id', '=', 'facebook_ad.call_to_action_id')
//                    ->leftjoin('facebook_ad_countries', 'facebook_ad_countries.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_url', 'facebook_ad_url.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
//                    ->toSql();
                    ->get();
                $data = (json_decode(json_encode($result), true));
//                dd($result);

                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                }
                $returnData->data = $result;
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
            }
        } else {
            $returnData->code = 402;
            $returnData->message = "Arguments not passed";
        }
        return json_encode($returnData);
    }

    public function getAdsBySimple($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip)
    {

//        return json_encode($where);
//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {

                    $getAdDataResp = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
//                    return json_encode($getAdDataResp);

                    $triage_resp = json_decode($getAdDataResp, true);
                    if ($triage_resp["data"] == null) {
                        $triage_resp["code"] = 400;
                        $triage_resp["data"] = null;
                        return $triage_resp;
                    }
                    $ids_sorted_with_skip_take = array_column($triage_resp["data"], "facebook_ad.id");
//                    return json_encode($ids_sorted_with_skip_take);
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') ', 'bindParams' => [$ids_sorted_with_skip_take]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByField($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);

                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
                }
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
//                    ->toSql();
                    ->get();
//                return($result);
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
//                return $data;
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;

            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }


    public function getAdsBySimpleForFavorite($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip, $ids)
    {

//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (true) {


                    $ids_sorted_with_skip_take = $ids;
//                    return $ids_sorted_with_skip_take;
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') ', 'bindParams' => [$ids_sorted_with_skip_take]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByFieldFav($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);


                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
                }
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
//                    ->toSql();
                    ->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;

            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsBySimpleForHtml($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip, $ids)
    {

//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (true) {


                    $ids_sorted_with_skip_take = $ids;
//                    return $ids_sorted_with_skip_take;
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') ', 'bindParams' => [$ids_sorted_with_skip_take]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByFieldHtml($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);


                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
                }
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
//                    ->toSql();
                    ->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;

            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsBySimpleForHidden($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip, $ids)
    {

//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (true) {


                    $ids_sorted_with_skip_take = $ids;
//                    return $ids_sorted_with_skip_take;
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') and hidden_ads.type in (?,?) ', 'bindParams' => [$ids_sorted_with_skip_take,1,2]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
//                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByField($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);
//                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByField($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByFieldHidden($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);


                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
                }
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('hidden_ads', 'facebook_ad.id', '=', 'hidden_ads.ad_id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
                    ->toSql();
//                    ->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;

            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }


    public function getAdsBySimpleForBug($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip, $ids)
    {

//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (true) {


                    $ids_sorted_with_skip_take = $ids;
//                    return $ids_sorted_with_skip_take;
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ') ', 'bindParams' => [$ids_sorted_with_skip_take]];
                    $order_by_field = "facebook_ad.id";
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByFieldBug($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);


                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);

                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found getAdsBySimple.');
                }
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('facebook_ad_bug_report', 'facebook_ad.id', '=', 'facebook_ad_bug_report.ad_id')
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->skip($skip)
                    ->take($take)
//                    ->toSql();
                    ->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;

            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }
    /*
     * For all condition query from dashboard
     * */
    public function getAdsComplex($where, $selectedColumns = ['*'], $order_column, $order_by, $take, $skip, $duplicate_possible)
    {
//        return 1;
        //        DB::enableQueryLog();


        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();
        $query = "";
//        return json_encode($where);
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                /*
                  $result = DB::table("facebook_ad")
                      ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                      ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=','facebook_ad_image_video.facebook_ad_id' )
                      ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
  //                    ->leftjoin('facebook_ad_countries', 'facebook_ad.id', '=','facebook_ad_countries.facebook_ad_id')
  //                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                      ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                      ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                      ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                      ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=' ,'facebook_ad_post_owners.id')
                      ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=' ,'facebook_ad_variants.id')
                      ->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                      ->select($selectedColumns)
                      ->orderBy($order_column, $order_by)
                      ->skip($skip)
                      ->take($take);
                  */
//                $adscount = 0;
//                    return 111;
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {
//                    if($where["from"]==0) {
//
//                        $getAdDataResp1 = $this->formatSearchQuery1($where, 'Ad data found by getAdsComplex.');
////                        return json_encode($getAdDataResp1);
//                        $triage_resp1 = json_decode($getAdDataResp1, true);
////                        return $triage_resp1;
////                        if ($triage_resp1["data"] == null) {
////                            $triage_resp1["code"] = 400;
////                            $triage_resp1["data"] = null;
//////                        return $triage_resp;
////                        }
//
//                         if($triage_resp1["data"] != null) {
//                             $ids_sorted_with_skip_take1 = array_column($triage_resp1["data"], "facebook_ad.id");
//                             $adscount = json_encode(count($ids_sorted_with_skip_take1));
//                         }
////
//                    }
////
//////                    return json_encode($selectedColumns);
//                    $selectedColumns =array_merge($selectedColumns,[DB::raw("$adscount as total")]);
//                    $selectedColumns =array_merge($selectedColumns,$adscount);
//                    return json_encode($selectedColumns);
//                    $selectedColumns = implode(',', $selectedColumns);
//                    return json_encode($selectedColumns);

//                        dd($where);
                    $getAdDataResp = $this->formatSearchQuery($where, 'Ad data found by getAdsComplex.');
//


//                    $adscount = 0;
                    $triage_resp = json_decode($getAdDataResp, true);
//                    dd($triage_resp);
                    if ($triage_resp["data"] == null) {
                        $triage_resp["code"] = 400;
                        $triage_resp["data"] = null;
                        return $triage_resp;
                    }
//                    return 1;
//                    return json_encode($triage_resp);
                    $ids_sorted_with_skip_take = array_column($triage_resp["data"], "facebook_ad.id");
                    $last_seen_of_last_ad = array_column($triage_resp["data"], "facebook_ad.last_seen");
//                    return json_encode($ids_sorted_with_skip_take);
                    $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
//                    return json_encode($clause4DeveloperId);
                    $where_with_sorted_id = ['rawQuery' => ' facebook_ad.id IN (' . $clause4DeveloperId . ')', 'bindParams' => [$ids_sorted_with_skip_take]];
//                    $order_by_field = "facebook_ad.id";
                    $order_by_field = $order_column;
                    $order_by_values_string = implode(',', $ids_sorted_with_skip_take);

//                    return 1;
                    $getAdOrderByFieldDataResp = $this->getAdsByOrderByField($where_with_sorted_id, $selectedColumns, $order_by_field, $order_by_values_string, $take, $skip);
                    $getAdOrderByFieldDataResp = json_decode($getAdOrderByFieldDataResp);
//                    $getAdOrderByFieldDataResp->last_seen_of_last_ad = end($last_seen_of_last_ad);

//                    return json_encode($getAdOrderByFieldDataResp, true);
                    return json_encode($getAdOrderByFieldDataResp, true);
                } else {
                    $where = $this->formatSearchQuery($where, 'Ad data found by getAdsComplex.');
                }

                $incomplete_query = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=', 'facebook_ad_variants.id');
                $result = "";
                if ($duplicate_possible) {
                    $result = $incomplete_query->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                        ->select($selectedColumns)
                        ->orderBy($order_column, $order_by)
                        ->skip($skip)
//                        ->take($take);
                    ->tosql();
                } else {
                    $result = $incomplete_query->select($selectedColumns)
                        ->orderBy($order_column, $order_by)
                        ->skip($skip)
                        ->take($take);
                }

                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//            $returnData->query = $query ;
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsComplex.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsComplex.';
                    $returnData->data = null;
                }

            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
        }
        if (getenv("DEBUG_MODE") == 1) {
            $returnData->queryDetails = $query;
        }
//            $returnData->queryDetails = $query ;
        return json_encode($returnData);
    }



    public function getJoindAds($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = $result = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_domains', 'facebook_ad.domain_id', '=', 'facebook_ad_domains.id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
                    ->leftjoin('country', 'country.id', '=', 'facebook_ad.country_id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('country_data', 'country_data.name', '=', 'country.country')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=', 'facebook_ad_variants.id')
                    ->leftjoin('facebook_category', 'facebook_category.id', '=', 'facebook_ad.category_id')
                    ->select($selectedColumns)
                    ->get();
//                return ($result);

                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }
    }

    //Aishwarya
    public function getCountry($fbid){
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $countryCode = "";
            $countryName =[];
            $where = func_get_arg(0);
            try {
                $country =
                $results = DB::table('facebook_ad_url')->where('facebook_ad_id',$fbid)->where('proxy_lander_status','!=',2)
//                  ->leftjoin('country_data','facebook_ad_url.country_code','=','country_data.iso')
                    ->select('country_code')
                    ->distinct()
                    ->get();
                $k =0;
                $j =0;
                foreach($results as $result){
                    $position = strpos($result->country_code,"||");
                    if($position >= 0){
                        $explodedCountry = explode('||',$result->country_code);
                    }
                    else{
                        $explodedCountry = explode('|',$result->country_code);
                    }


                    for($i=0;$i<count($explodedCountry);$i++)
                    {
                        $countryData = DB::table('country_data')->where('iso',$explodedCountry[$i])->value('name');

                        if($countryName == null){

                            $countryName[$k]['country'] = $countryData;
                            $countryName[$k]['code'] = $explodedCountry[$i];
                            $k++;
                        }
                        else{
                            foreach ($countryName as $item) {

                                if (isset($item['country']) && $item['country'] == $countryData) {
                                    $j=0;
                                    break;
                                } else {
//                                    print_r($explodedCountry[$i]);
                                    $j++;
                                }
                            }
                            if($j>0)
                            {
                                $countryName[$k]['country'] = $countryData;
                                $countryName[$k]['code'] = $explodedCountry[$i];
                                $k++;
                            }
                            $j=0;
                        }




//                        if(!in_array($countryData,$countryName)) {
//                            $k++;
//                            print_r($explodedCountry[$i]);
//                            $countryName[$k]['country'] = $countryData;
//                            $countryName[$k]['code'] = $explodedCountry[$i];
//                        }
                    }
                }
                if ($countryName != null) {
                    $returnData->code = 200;
                    $returnData->message = 'Got country.';
                    $returnData->data = $countryName;

                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No country';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }
    }


    //Aishwarya to get country redirect
    public function getCountriesOutgoing($fbid,$code){
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table('facebook_ad_outgoing_links')->where('facebook_ad_id',$fbid)->where('country_code',$code)->get();
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }
    }

    public function getJoindAdsOneData($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = $result = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
                    ->leftjoin('country', 'country.id', '=', 'facebook_ad.country_id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=', 'facebook_ad_variants.id')
                    ->leftjoin('facebook_category', 'facebook_category.category_name', '=', 'facebook_ad.category_id')
                    ->select($selectedColumns)
                    ->take(1)
                    ->get();

                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }
    }

    public function getJoindAdsOneDataRand($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = $result = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->select($selectedColumns)
                    ->take(1)
                    ->orderBy(DB::raw('RAND()'))
                    ->get();

                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }
    }

    //raushan(01-02-2018): for getting the ads based on advertiser,key,domain for guest page
    public function getAdsByAdvertiser($where, $selectedColumns, $order_column, $order_by, $take, $skip, $wherePostOwner)
    {
        if (func_num_args() > 0) {
            try {
                return DB::table($this->table)
                    ->join('facebook_ad_post_owners', 'facebook_ad_post_owners.id', '=', 'facebook_ad.post_owner_id')
                    ->join('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad_image_video.facebook_ad_id', '=', 'facebook_ad.id')
                    ->join('facebook_ad_variants', 'facebook_ad_variants.id', '=', 'facebook_ad.default_variant_id')
//                    ->where('facebook_ad.post_owner_id',$postOwnerId)
                    ->whereRaw($wherePostOwner)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
                    ->orderBy($order_column, $order_by)
                    ->take($take)
                    ->skip($skip)
                    ->get();
            } catch (\Exception $e) {
                throw new \Exception("DB Exception:" . $e->getMessage());
            }
        } else {
            throw new \Exception("Arguments not passed");
        }
    }

    /**
     * @param $result
     * @return mixed
     */
    private function formatQueryString($result)//: string
    {
        $result = str_ireplace("LEFT JOIN", "\rLEFT JOIN", $result);
        $result = str_ireplace("WHERE", "\rWHERE", $result);
        $result = str_ireplace("AND", "\rAND", $result);
        $result = str_ireplace("ORDER", "\rORDER", $result);
        $result = str_ireplace("LIMIT", "\rLIMIT", $result);
        $result = str_ireplace("OFFSET", "\rOFFSET", $result);
        $result = str_ireplace("FROM", "\rFROM", $result);
        $result = str_ireplace("SELECT", "SELECT SQL_NO_CACHE", $result);
        return $result;
    }

    private function cCount($thing)
    {
        return $thing == null ? 0 : count($thing);
    }

    private function formatSearchQuery($whereTriage, $message)
    {

        try{


        $returnData = new \stdClass();

//

        if (config('services.search.enabled') && $this->elasticsearch->ping()) {

            $serch_obj = Search_mix::getInstance();

            if (isset($whereTriage["domain_matched_ids"])) {
                $serch_obj->setDomainMatchedIds($whereTriage["domain_matched_ids"]);

            }
            if (isset($whereTriage["post_owner_name"])) {
                $serch_obj->setPostOwnerName($whereTriage["post_owner_name"]);
            }

            if (isset($whereTriage["url"])) {
                $serch_obj->setUrl($whereTriage["url"]);
            }
            if (isset($whereTriage["keyword"])) {
                $serch_obj->setKeyword($whereTriage["keyword"]);
            }

            if (isset($whereTriage["mix_data"])) {
//                return json_encode($whereTriage["mixdata"]);
                $serch_obj->setMixdata($whereTriage["mix_data"]);
            }


            if (isset($whereTriage["html_content"])) {
//                return json_encode($whereTriage["html_content"]);
//                dd($whereTriage["html_content"]);
                $serch_obj->setHtmlContent($whereTriage["html_content"]);
            }
//            dd(2222);
            if (isset($whereTriage["call_to_action"])) {
                $serch_obj->setCallToAction($whereTriage["call_to_action"]);
            }
            if (isset($whereTriage["country"])) {
                $serch_obj->setCountry($whereTriage["country"]);
            }
            if (isset($whereTriage["type"])) {
                $serch_obj->setAdType($whereTriage["type"]);
            }
            if (isset($whereTriage["ad_position"])) {
                $serch_obj->setAdPosition($whereTriage["ad_position"]);
            }
            if (isset($whereTriage["gender"])) {
                $serch_obj->setGender($whereTriage["gender"]);
            }
            if (isset($whereTriage["lower_age_seen"])) {
                $serch_obj->setLowerAgeSeen($whereTriage["lower_age_seen"]);
            }/**/
            if (isset($whereTriage["last_seen"])) {
                $serch_obj->setLastSeen($whereTriage["last_seen"]);
            }
            if (isset($whereTriage["post_date"])) {
                $serch_obj->setPostDate($whereTriage["post_date"]);
            }
            if (isset($whereTriage["needle"])) {
                $serch_obj->setNeedle($whereTriage["needle"]);
            }
            if (isset($whereTriage["status"])) {
                $serch_obj->setStatus($whereTriage["status"]);
            }
            if (isset($whereTriage["built_with"])) {
                $serch_obj->setBuiltWith($whereTriage["built_with"]);
            }
            if (isset($whereTriage["track"])) {
                $serch_obj->setTrack($whereTriage["track"]);
            }
            if (isset($whereTriage["source"])) {
                $serch_obj->setSource($whereTriage["source"]);
            }
            if (isset($whereTriage["funnel"])) {
                $serch_obj->setFunnel($whereTriage["funnel"]);
            }
            if (isset($whereTriage["affiliate"])) {
                $serch_obj->setAffiliate($whereTriage["affiliate"]);
            }
            if (isset($whereTriage["lang"])) {
                $serch_obj->setLangDetect($whereTriage["lang"]);
            }
            if (isset($whereTriage["size"])) {
                $serch_obj->setSize($whereTriage["size"]);
            }
            if (isset($whereTriage["from"])) {
                $serch_obj->setFrom($whereTriage["from"]);
            }
            if (isset($whereTriage["sort"]['field'])) {
                $serch_obj->setSortField($whereTriage["sort"]['field']);

                //Aishwarya
//                if(Session::has('ads_last_seen')){
//                    $serch_obj->setFilterField(Session::has('ads_last_seen'));
//                }else{
//                    $serch_obj->setFilterField(date('Y-m-d h:m:s'));
//
//                }
            }
            if (isset($whereTriage["sort"]['method'])) {
                $serch_obj->setSortMethod($whereTriage["sort"]['method']);
            }
            if (isset($whereTriage["tags"])) {
                $serch_obj->setTags($whereTriage["tags"]);
            }
            if (isset($whereTriage["html"])) {
                $serch_obj->setHtml($whereTriage["html"]);
            }
            if (isset($whereTriage["comment_data"])) {
                $serch_obj->setCommentdata($whereTriage["comment_data"]);
            }

            if (isset($whereTriage["verified"])) {
//                dd($whereTriage["verified"]);
                $serch_obj->setVerified($whereTriage["verified"]);
            }
//
            if (isset($whereTriage["page_creation"])) {
                $serch_obj->setPageCreation($whereTriage["page_creation"]);
//                dd()
            }

            if (isset($whereTriage["platform"])) {
                $serch_obj->setPlatform($whereTriage["platform"]);
            }
            if (isset($whereTriage["discoverer_user_id"])) {
//                return 1;
                $serch_obj->setDiscovereruserid($whereTriage["discoverer_user_id"]);
            }


            if (isset($whereTriage["likes"]) && $whereTriage["likes"] != "") {

                $serch_obj->setLikes($whereTriage["likes"]);
            }
            if (isset($whereTriage["comments"]) && $whereTriage["comments"] != "") {

                $serch_obj->setComments($whereTriage["comments"]);
            }
            if (isset($whereTriage["shares"]) && $whereTriage["shares"] != "") {

                $serch_obj->setShares($whereTriage["shares"]);
            }

//            return json_encode($whereTriage);
//            return json_encode($whereTriage);
//            return 22;
            $serch_obj->buildParams();

//            Log::info($serch_obj->getCompileParams());
//            Log::info($whereTriage);
//            return $serch_obj->getCompileParams();
            $returnData->data = $serch_obj->run();

//            dd($returnData->data);
            //        --------- version -----------
            $size = 9;
            $from = 0;
            if (isset($whereTriage["version"]) && $whereTriage["version"] !== "NA") {   // version

                $select_version = [DB::raw('distinct facebook_ad_meta_data.facebook_ad_id')];
                $facebook_ad_meta_data = Facebook_ad_meta_data::getInstance();
                if (isset($whereTriage["size"])) {
                    $size = $whereTriage["size"];
                }
                if (isset($whereTriage["from"])) {
                    $from = $whereTriage["from"];
                }

                //$domain_response = json_decode($facebook_ad_meta_data->getFacebook_ad_meta_data($whereDomainTriage, $select_domain));
                $returnData = json_decode($facebook_ad_meta_data->getFacebook_ad_meta_dataESVersion(["version" => $whereTriage["version"]], $select_version, $size, $from));
                return json_encode($returnData);
            }
//         --------- version -----------

//       --------- AdFbUsers Search -----------
            $size = 9;
            $from = 0;
            if (isset($whereTriage["selected_user"]) && $whereTriage["selected_user"] !== "NA") {


                if (isset($whereTriage["size"])) {
                    $size = $whereTriage["size"];
                }
                if (isset($whereTriage["from"])) {
                    $from = $whereTriage["from"];
                }

//                return json_encode($whereTriage["selected_user"]);
                $facebook_ad_usersObj = Facebook_ad_users::getInstance();
                $returnData = json_decode($facebook_ad_usersObj->getFacebookAdIdFromES($whereTriage["selected_user"], $size, $from));
                return json_encode($returnData);
            }
//        --------- AdFbUsers Search -----------


            if (isset($returnData->data[0])) {
                $returnData->code = 200;
                $returnData->message = $message;//'Ad data found by getAdsByTraige3.';
            } else {
                $returnData->code = 400;
                $returnData->message = 'No ' . $message;//'No Ad data found by getAdsByTraige3.';
                $returnData->data = null;
            }

//            dd($returnData);
            return json_encode($returnData);
        } else {
            if (isset($whereTriage["domain_matched_ids"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.id IN (' . $whereTriage["domain_matched_ids_req"] . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["domain_matched_ids"];
            }
            if (isset($whereTriage["advertiser"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_post_owners.post_owner_name like ? ';
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_owner_name"] . "%";
            }
            if (isset($whereTriage["domain"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . '  facebook_ad_url.url like ? ';
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = "%" . $whereTriage["url"] . "%";
            }
            if (isset($whereTriage["keyword"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' match ( facebook_ad_variants.title , facebook_ad_variants.text , facebook_ad_variants.newsfeed_description ) against ( ? in boolean mode ) ';
                $whereTriage["bindParams"][($whereTriage["bindParams"] == null ? 0 : count($whereTriage["bindParams"]))] = '"' . $whereTriage["keyword"] . '"';
            }
            if (isset($whereTriage["call_to_action"])) {
                $clause4DeveloperCTA = implode(',', array_fill(0, count($whereTriage["call_to_action_req"]), '?'));
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_call_to_actions.action IN (' . $clause4DeveloperCTA . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["call_to_action"];
            }
            if (isset($whereTriage["country"])) {
                $clause4DeveloperCountry = implode(',', array_fill(0, count($whereTriage["country_req"]), '?'));
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' country_only.country IN (' . $clause4DeveloperCountry . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["country"];
            }
            if (isset($whereTriage["type"])) {
                $clause4DeveloperType = implode(',', array_fill(0, count($whereTriage["type_req"]), '?'));
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.type IN (' . $clause4DeveloperType . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["type"];
            }
            if (isset($whereTriage["ad_position"])) {
                $clause4DeveloperAP = implode(',', array_fill(0, count($whereTriage["ad_position_req"]), '?'));
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.ad_position IN (' . $clause4DeveloperAP . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["ad_position"];
            }
            if (isset($whereTriage["gender"])) {
                $clause4DeveloperGender = implode(',', array_fill(0, count($whereTriage["gender_req"]), '?'));
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_users.Gender IN (' . $clause4DeveloperGender . ') ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["gender"];
            }
            if (isset($whereTriage["lower_age_seen"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.lower_age_seen BETWEEN ? AND ? ) ';
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["lower_age_seen"]["lower_age"];
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["lower_age_seen"]["upper_age"];
            }
            if (isset($whereTriage["last_seen"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.last_seen BETWEEN ? AND ? ) ';
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["last_seen"]["lower_date"];
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["last_seen"]["upper_date"];
            }
            if (isset($whereTriage["post_date"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.post_date BETWEEN ? AND ? ) ';
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_date"]["lower_date"];
                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_date"]["upper_date"];
            }
            if (isset($whereTriage["needle"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.id < ? ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["needle"];
            }
            if (isset($whereTriage["status"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.status IN (? , ?)  ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["status"];
            }
            if (isset($whereTriage["built_with"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.built_with = ? ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["built_with"];
            }
            if (isset($whereTriage["track"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ( ';
                foreach ($whereTriage["track"] as $key => $tr) {
                    if ($key == 0) {
                        $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_url.url LIKE ?  ';
                    } else {
                        $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' OR facebook_ad_url.url LIKE ?  ';
                    }
                    $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $tr . "%";
                }
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ) ';
            }
            if (isset($whereTriage["source"])) {
                $isSourceMultiple = false;
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' AND ( ';
                if (in_array("desktop", $whereTriage["source"])) {
                    $isSourceMultiple = true;
                    $source = " facebook_ad_meta_data.firstSeenOnDesktop ";
                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
                }
                if (in_array("ios", $whereTriage["source"])) {
                    if (in_array("desktop", $whereTriage["source"])) {
                        $source = " OR facebook_ad_meta_data.firstSeenOnIos ";
                    } else {
                        $source = " facebook_ad_meta_data.firstSeenOnIos ";
                        //                }
                    }
                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
                }
                if (in_array("android", $whereTriage["source"])) {
                    if (in_array("desktop", $whereTriage["source"]) || in_array("ios", $whereTriage["source"])) {
                        $source = " OR facebook_ad_meta_data.firstSeenOnAndroid ";
                    } else {
                        $source = " facebook_ad_meta_data.firstSeenOnAndroid ";
                    }
                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
                }
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ) ';
            }
            if (isset($whereTriage["funnel"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.built_with_analytics_tracking like ? ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $whereTriage["funnel"] . "%";
            }
            if (isset($whereTriage["affiliate"])) {
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.destination_url LIKE ? ';
                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $whereTriage["affiliate"] . "%";
            }
            return $whereTriage;
        }}catch (\Exception $e){
            dd($e->getMessage());
        }
    }

//    private function formatSearchQuery1($whereTriage, $message)
//    {
//
//        $returnData = new \stdClass();
//        if (config('services.search.enabled') && $this->elasticsearch->ping()) {
//
//            $serch_obj = Search_mix::getInstance();
//
//            if (isset($whereTriage["domain_matched_ids"])) {
//                $serch_obj->setDomainMatchedIds($whereTriage["domain_matched_ids"]);
//            }
//            if (isset($whereTriage["post_owner_name"])) {
//                $serch_obj->setPostOwnerName($whereTriage["post_owner_name"]);
//            }
//            if (isset($whereTriage["url"])) {
//                $serch_obj->setUrl($whereTriage["url"]);
//            }
//            if (isset($whereTriage["keyword"])) {
//                $serch_obj->setKeyword($whereTriage["keyword"]);
//            }
//            if (isset($whereTriage["call_to_action"])) {
//                $serch_obj->setCallToAction($whereTriage["call_to_action"]);
//            }
//            if (isset($whereTriage["country"])) {
//                $serch_obj->setCountry($whereTriage["country"]);
//            }
//            if (isset($whereTriage["type"])) {
//                $serch_obj->setAdType($whereTriage["type"]);
//            }
//            if (isset($whereTriage["ad_position"])) {
//                $serch_obj->setAdPosition($whereTriage["ad_position"]);
//            }
//            if (isset($whereTriage["gender"])) {
//                $serch_obj->setGender($whereTriage["gender"]);
//            }
//            if (isset($whereTriage["lower_age_seen"])) {
//                $serch_obj->setLowerAgeSeen($whereTriage["lower_age_seen"]);
//            }/**/
//            if (isset($whereTriage["last_seen"])) {
//                $serch_obj->setLastSeen($whereTriage["last_seen"]);
//            }
//            if (isset($whereTriage["post_date"])) {
//                $serch_obj->setPostDate($whereTriage["post_date"]);
//            }
//            if (isset($whereTriage["needle"])) {
//                $serch_obj->setNeedle($whereTriage["needle"]);
//            }
//            if (isset($whereTriage["status"])) {
//                $serch_obj->setStatus($whereTriage["status"]);
//            }
//            if (isset($whereTriage["built_with"])) {
//                $serch_obj->setBuiltWith($whereTriage["built_with"]);
//            }
//            if (isset($whereTriage["track"])) {
//                $serch_obj->setTrack($whereTriage["track"]);
//            }
//            if (isset($whereTriage["source"])) {
//                $serch_obj->setSource($whereTriage["source"]);
//            }
//            if (isset($whereTriage["funnel"])) {
//                $serch_obj->setFunnel($whereTriage["funnel"]);
//            }
//            if (isset($whereTriage["affiliate"])) {
//                $serch_obj->setAffiliate($whereTriage["affiliate"]);
//            }
//            if (isset($whereTriage["lang"])) {
//                $serch_obj->setLangDetect($whereTriage["lang"]);
//            }
////            if (isset($whereTriage["size"])) {
////                $serch_obj->setSize($whereTriage["size"]);
////            }
//            if (isset($whereTriage["from"])) {
//                $serch_obj->setFrom($whereTriage["from"]);
//            }
//            if (isset($whereTriage["sort"]['field'])) {
//                $serch_obj->setSortField($whereTriage["sort"]['field']);
//            }
//            if (isset($whereTriage["sort"]['method'])) {
//                $serch_obj->setSortMethod($whereTriage["sort"]['method']);
//            }
//            if (isset($whereTriage["tags"])) {
//                $serch_obj->setTags($whereTriage["tags"]);
//            }
//            if (isset($whereTriage["html"])) {
//                $serch_obj->setHtml($whereTriage["html"]);
//            }
//            if (isset($whereTriage["comment_data"])) {
//                $serch_obj->setCommentdata($whereTriage["comment_data"]);
//            }
////            if (isset($whereTriage["platform"])) {
////                $serch_obj->setPlatform($whereTriage["platform"]);
////            }
////            if (isset($whereTriage["discoverer_user_id"])) {
////                $serch_obj->setDiscoverer_user_id($whereTriage["discoverer_user_id"]);
////            }
//            if (isset($whereTriage["likes"]) && $whereTriage["likes"] != "") {
//
//                $serch_obj->setLikes($whereTriage["likes"]);
//            }
//            if (isset($whereTriage["comments"]) && $whereTriage["comments"] != "") {
//
//                $serch_obj->setComments($whereTriage["comments"]);
//            }
//            if (isset($whereTriage["shares"]) && $whereTriage["shares"] != "") {
//
//                $serch_obj->setShares($whereTriage["shares"]);
//            }
////            return json_encode($whereTriage);
////            return 22;
//            $serch_obj->buildParams();
////            Log::info($serch_obj->getCompileParams());
////            return $serch_obj->getCompileParams();
//            $returnData->data = $serch_obj->run();
//
//
//            //        --------- version -----------
//            $size = 9;
//            $from = 0;
//            if (isset($whereTriage["version"]) && $whereTriage["version"] !== "NA") {   // version
//                $select_version = [DB::raw('distinct facebook_ad_meta_data.facebook_ad_id')];
//                $facebook_ad_meta_data = Facebook_ad_meta_data::getInstance();
//                if (isset($whereTriage["size"])) {
//                    $size = $whereTriage["size"];
//                }
//                if (isset($whereTriage["from"])) {
//                    $from = $whereTriage["from"];
//                }
//
//                //$domain_response = json_decode($facebook_ad_meta_data->getFacebook_ad_meta_data($whereDomainTriage, $select_domain));
//                $returnData = json_decode($facebook_ad_meta_data->getFacebook_ad_meta_dataESVersion(["version" => $whereTriage["version"]], $select_version, $size, $from));
//                return json_encode($returnData);
//            }
////         --------- version -----------
//
////       --------- AdFbUsers Search -----------
//            $size = 9;
//            $from = 0;
//            if (isset($whereTriage["selected_user"]) && $whereTriage["selected_user"] !== "NA") {
//                if (isset($whereTriage["size"])) {
//                    $size = $whereTriage["size"];
//                }
//                if (isset($whereTriage["from"])) {
//                    $from = $whereTriage["from"];
//                }
//
////                return json_encode($whereTriage["selected_user"]);
//                $facebook_ad_usersObj = Facebook_ad_users::getInstance();
//                $returnData = json_decode($facebook_ad_usersObj->getFacebookAdIdFromES($whereTriage["selected_user"], $size, $from));
//                return json_encode($returnData);
//            }
////        --------- AdFbUsers Search -----------
//
//
//            if (isset($returnData->data[0])) {
//                $returnData->code = 200;
//                $returnData->message = $message;//'Ad data found by getAdsByTraige3.';
//            } else {
//                $returnData->code = 400;
//                $returnData->message = 'No ' . $message;//'No Ad data found by getAdsByTraige3.';
//                $returnData->data = null;
//            }
//            return json_encode($returnData);
//        } else {
//            if (isset($whereTriage["domain_matched_ids"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.id IN (' . $whereTriage["domain_matched_ids_req"] . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["domain_matched_ids"];
//            }
//            if (isset($whereTriage["advertiser"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_post_owners.post_owner_name like ? ';
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_owner_name"] . "%";
//            }
//            if (isset($whereTriage["domain"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . '  facebook_ad_url.url like ? ';
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = "%" . $whereTriage["url"] . "%";
//            }
//            if (isset($whereTriage["keyword"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' match ( facebook_ad_variants.title , facebook_ad_variants.text , facebook_ad_variants.newsfeed_description ) against ( ? in boolean mode ) ';
//                $whereTriage["bindParams"][($whereTriage["bindParams"] == null ? 0 : count($whereTriage["bindParams"]))] = '"' . $whereTriage["keyword"] . '"';
//            }
//            if (isset($whereTriage["call_to_action"])) {
//                $clause4DeveloperCTA = implode(',', array_fill(0, count($whereTriage["call_to_action_req"]), '?'));
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_call_to_actions.action IN (' . $clause4DeveloperCTA . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["call_to_action"];
//            }
//            if (isset($whereTriage["country"])) {
//                $clause4DeveloperCountry = implode(',', array_fill(0, count($whereTriage["country_req"]), '?'));
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' country_only.country IN (' . $clause4DeveloperCountry . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["country"];
//            }
//            if (isset($whereTriage["type"])) {
//                $clause4DeveloperType = implode(',', array_fill(0, count($whereTriage["type_req"]), '?'));
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.type IN (' . $clause4DeveloperType . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["type"];
//            }
//            if (isset($whereTriage["ad_position"])) {
//                $clause4DeveloperAP = implode(',', array_fill(0, count($whereTriage["ad_position_req"]), '?'));
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.ad_position IN (' . $clause4DeveloperAP . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["ad_position"];
//            }
//            if (isset($whereTriage["gender"])) {
//                $clause4DeveloperGender = implode(',', array_fill(0, count($whereTriage["gender_req"]), '?'));
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_users.Gender IN (' . $clause4DeveloperGender . ') ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["gender"];
//            }
//            if (isset($whereTriage["lower_age_seen"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.lower_age_seen BETWEEN ? AND ? ) ';
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["lower_age_seen"]["lower_age"];
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["lower_age_seen"]["upper_age"];
//            }
//            if (isset($whereTriage["last_seen"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.last_seen BETWEEN ? AND ? ) ';
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["last_seen"]["lower_date"];
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["last_seen"]["upper_date"];
//            }
//            if (isset($whereTriage["post_date"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' (facebook_ad.post_date BETWEEN ? AND ? ) ';
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_date"]["lower_date"];
//                $whereTriage["bindParams"][count($whereTriage["bindParams"])] = $whereTriage["post_date"]["upper_date"];
//            }
//            if (isset($whereTriage["needle"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.id < ? ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["needle"];
//            }
//            if (isset($whereTriage["status"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad.status IN (? , ?)  ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["status"];
//            }
//            if (isset($whereTriage["built_with"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.built_with = ? ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = $whereTriage["built_with"];
//            }
//            if (isset($whereTriage["track"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ( ';
//                foreach ($whereTriage["track"] as $key => $tr) {
//                    if ($key == 0) {
//                        $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_url.url LIKE ?  ';
//                    } else {
//                        $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' OR facebook_ad_url.url LIKE ?  ';
//                    }
//                    $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $tr . "%";
//                }
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ) ';
//            }
//            if (isset($whereTriage["source"])) {
//                $isSourceMultiple = false;
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' AND ( ';
//                if (in_array("desktop", $whereTriage["source"])) {
//                    $isSourceMultiple = true;
//                    $source = " facebook_ad_meta_data.firstSeenOnDesktop ";
//                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
//                }
//                if (in_array("ios", $whereTriage["source"])) {
//                    if (in_array("desktop", $whereTriage["source"])) {
//                        $source = " OR facebook_ad_meta_data.firstSeenOnIos ";
//                    } else {
//                        $source = " facebook_ad_meta_data.firstSeenOnIos ";
//                        //                }
//                    }
//                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
//                }
//                if (in_array("android", $whereTriage["source"])) {
//                    if (in_array("desktop", $whereTriage["source"]) || in_array("ios", $whereTriage["source"])) {
//                        $source = " OR facebook_ad_meta_data.firstSeenOnAndroid ";
//                    } else {
//                        $source = " facebook_ad_meta_data.firstSeenOnAndroid ";
//                    }
//                    $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ' . $source . ' IS NOT NULL ';
//                }
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' ) ';
//            }
//            if (isset($whereTriage["funnel"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.built_with_analytics_tracking like ? ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $whereTriage["funnel"] . "%";
//            }
//            if (isset($whereTriage["affiliate"])) {
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] == "" ? "" : $whereTriage['rawQuery'] . ' AND ';
//                $whereTriage['rawQuery'] = $whereTriage['rawQuery'] . ' facebook_ad_meta_data.destination_url LIKE ? ';
//                $whereTriage["bindParams"][$this->cCount($whereTriage["bindParams"])] = "%" . $whereTriage["affiliate"] . "%";
//            }
//            return $whereTriage;
//        }
//    }

    public function getAdsByTriage1($whereTriage, $select_triage)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {
                    return $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige1.');
                } else {
                    $whereTriage = $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige1.');
                }
                $result = $result = DB::table("facebook_ad_variants")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad', 'facebook_ad_variants.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($select_triage);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 1) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByTriage1.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByTriage1.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->triageQueryDetails = $query;
            }
//            $returnData->triageQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    /*
     * Special condition for order by fields
     * */
    public function getAdsByOrderByField($where, $selectedColumns = ['*'],$order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('facebook_ad_countries_only', 'facebook_ad.id', '=', 'facebook_ad_countries_only.facebook_ad_id')
                    ->leftjoin('country_only', 'facebook_ad_countries_only.country_only_id', '=', 'country_only.id')
                    //                      ->leftjoin('facebook_ad_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_ad_users.facebook_ad_id')
                    ->select($selectedColumns)
                    ->groupBy('facebook_ad.id')
//                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
                    ->orderBy($order_by_field,'desc');
//                    ->toSql();
//                dd($result);
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
//                dd($e->getMessage());
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 0) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsByOrderByFieldHidden($where, $selectedColumns = ['*'], $order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('hidden_ads', 'facebook_ad.id', '=', 'hidden_ads.ad_id')
                    ->groupby("facebook_ad.id")
                    ->select($selectedColumns);
//                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 0) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsByOrderByFieldFav($where, $selectedColumns = ['*'], $order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('hidden_ads', 'facebook_ad.id', '=', 'hidden_ads.ad_id')
                    ->groupby("hidden_ads.ad_id")
                    ->select($selectedColumns);
//                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 0) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsByOrderByFieldHtml($where, $selectedColumns = ['*'], $order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
//                    ->leftjoin('hidden_ads', 'facebook_ad.id', '=', 'hidden_ads.ad_id')
//                    ->groupby("hidden_ads.ad_id")
                    ->select($selectedColumns);
//                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 0) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }


    public function getAdsByOrderByFieldBug($where, $selectedColumns = ['*'], $order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 0 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->leftjoin('facebook_ad_bug_report', 'facebook_ad.id', '=', 'facebook_ad_bug_report.ad_id')
                    ->select($selectedColumns)
                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 0) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 0 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 0) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsByOrderByFieldWithFBUsersData($where, $selectedColumns = ['*'], $order_by_field, $order_by_values, $take, $skip)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $query = "";
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_users', 'facebook_ad.id', '=', 'facebook_ad_users.facebook_ad_id')
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->select($selectedColumns)
                    ->orderByRaw(DB::raw("FIELD(" . $order_by_field . ", " . $order_by_values . " )"));
//                    ->skip($skip)
//                    ->take($take);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 1) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByOrderByField.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByOrderByField.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            if (getenv("DEBUG_MODE") == 1) {
                $returnData->orderByFieldQueryDetails = $query;
            }
//            $returnData->orderByFieldQueryDetails = $query ;
            return json_encode($returnData);
        }
    }

    protected function filterIntForIDs($IDs, $fieldName, $start, $end)
    {
        $params = array();
        $params['index'] = $this->table;
        $params['type'] = $this->searchableAs();
        $params['body'] = [
            'query' => [
                'bool' => [
                    "must" => [
                        "query_string" => [
                            "default_field" => "id",
                            "query" => "(" . implode(") OR (", $IDs) . ")"
                        ]
                    ],
                    'filter' => [
                        'range' => [
                            $fieldName => [
                                'gte' => $start,
                                'lte' => $end
                            ]
                        ]
                    ]
                ],
            ]
        ];
        $search = $this->elasticsearch->search($params);
        return $this->viewResult($search);
    }

    protected function filterInt($fieldName, $start, $end)
    {
        $params = array();
        $params['index'] = $this->table;
        $params['type'] = $this->searchableAs();
        $params['body'] = [
            'query' => [
                'bool' => [
                    'filter' => [
                        'range' => [
                            $fieldName => [
                                'gte' => $start,
                                'lte' => $end,
                            ]
                        ]
                    ]
                ],
            ]
        ];
        $search = $this->elasticsearch->search($params);
        return $this->viewResult($search);
    }

    protected function filterDateForIDs($IDs, $fieldName, $startDate, $endDate)
    {
        $params = array();
        $params['index'] = $this->table;
        $params['type'] = $this->searchableAs();
        $params['body'] = [
            'query' => [
                'bool' => [
                    "must" => [
                        "query_string" => [
                            "default_field" => "id",
                            "query" => "(" . implode(") OR (", $IDs) . ")"
                        ]
                    ],
                    'filter' => [
                        'range' => [
                            $fieldName => [
                                'gte' => $startDate,//"2017-11-18 00:00:00",
                                'lte' => $endDate,//"2017-11-19 23:59:00",
                                "format" => "yyyy-MM-dd' 'HH:mm:ss"
                            ]
                        ]
                    ]
                ],
            ]
        ];
        $search = $this->elasticsearch->search($params);
        return $this->viewResult($search);
    }

    protected function filterDate($fieldName, $startDate, $endDate)
    {
        $params = array();
        $params['index'] = $this->table;
        $params['type'] = $this->searchableAs();
        $params['body'] = [
            'query' => [
                'bool' => [
                    'filter' => [
                        'range' => [
                            $fieldName => [
                                'gte' => $startDate,
                                'lte' => $endDate,
                                "format" => "yyyy-MM-dd' 'HH:mm:ss"
                            ]
                        ]
                    ]
                ],
            ]
        ];
        $search = $this->elasticsearch->search($params);
        return $this->viewResult($search);
    }

    public function getAdsByTraige2($whereTriage, $select_triage)
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $whereTriage = func_get_arg(0);
            try {
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {
                    return $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige2.');
                } else {
                    $whereTriage = $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige2.');
                }

                $result = DB::table("facebook_ad")
                    ->whereRaw($whereTriage['rawQuery'], isset($whereTriage['bindParams']) ? $whereTriage['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
//                    ->leftjoin('facebook_ad_countries', 'facebook_ad.id', '=','facebook_ad_countries.facebook_ad_id')
//                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
//                    ->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=', 'facebook_ad_variants.id')
                    ->select($select_triage);
//                    ->toSql();
//                    ->get();
                if (getenv("DEBUG_MODE") == 1) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByTraige2.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByTraige2.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->queryDetails = $query;
            }
//            $returnData->queryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getAdsByTraige3($whereTriage, $select_triage)
    {

        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $whereTriage = func_get_arg(0);
            try {
                if (config('services.search.enabled') && $this->elasticsearch->ping()) {
//                    dd($this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige3.'));
                    return $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige3.');
                } else {

                    $whereTriage = $this->formatSearchQuery($whereTriage, 'Ad data found by getAdsByTraige3.');
                }

                $result = DB::table("facebook_ad")
                    ->whereRaw($whereTriage['rawQuery'], isset($whereTriage['bindParams']) ? $whereTriage['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_call_to_actions', 'facebook_ad.call_to_action_id', '=', 'facebook_call_to_actions.id', '=')
//                    ->leftjoin('facebook_ad_countries', 'facebook_ad.id', '=','facebook_ad_countries.facebook_ad_id')
//                    ->leftjoin('country', 'facebook_ad_countries.country_id', '=', 'country.id')
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->leftjoin('facebook_users', 'facebook_ad.discoverer_user_id', '=', 'facebook_users.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
//                    ->leftjoin('facebook_ad_url', 'facebook_ad.id', '=', 'facebook_ad_url.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.default_variant_id', '=', 'facebook_ad_variants.id')
                    ->select($select_triage);
//                    ->toSql();
//                    ->get();
                //}
                if (getenv("DEBUG_MODE") == 1) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by getAdsByTraige3.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsByTraige3.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->queryDetails = $query;
            }
//            $returnData->queryDetails = $query ;
            return json_encode($returnData);
        }
    }

    /*
     * Fetch facebook ad by country
     * */
    public function getAdByCountry($where, $selectedColumns = ['*'])
    {
        //        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";
        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = $result = DB::table("facebook_ad")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->select($selectedColumns)
                    ->orderBy("facebook_ad.id")
                    ->take(1);
                if (getenv("DEBUG_MODE") == 1) {
                    $returnData->queryString = $this->formatQueryString($result->toSql());
                }
//                $returnData->queryString = $this->formatQueryString($result->toSql());
                $result = $result->get();
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found by get ad by country.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by get ad by country.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->queryDetails = $query;
            }
//            $returnData->queryDetails = $query ;
            return json_encode($returnData);
        }
    }

    public function getOneAdWithMetaData($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
//                    ->leftjoin('facebook_ad_analytics', 'facebook_ad_analytics.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
//                    ->orderby("facebook_ad.id")
//                    ->orderby("facebook_ad_analytics.id","desc")
                    ->take(1)
//                    ->tosql();
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getManyAdWithMetaData($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table("facebook_ad_meta_data")
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->select($selectedColumns)
                    ->orderby("facebook_ad_id","desc")
                    ->take(100)
//                    ->toSql();
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getManyAdWithMetaDatawithoutcountry($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
//                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->select($selectedColumns)
                    ->take(100)
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getOneAdWithMetaDataRandom($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('country_only', 'facebook_ad.country_only_id', '=', 'country_only.id')
                    ->select($selectedColumns)
                    ->orderBy(DB::raw('RAND()'))
                    ->take(1)
                    ->get();
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getOneAdWithMetaDataFbtargetRandom($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->leftjoin('facebook_ad_targeted_countries', 'facebook_ad_targeted_countries.ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
//                    ->orderBy(DB::raw('RAND()'))
                    ->take(1)
//                    ->toSql();
                    ->get();

                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getfbandMeta($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
                    ->orderBy("facebook_ad.id","desc")

//                    ->toSql();
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getfbid($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
                    ->orderBy("facebook_ad.id","desc")

//                    ->toSql();
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }


    public function getAdsById($where, $selectedColumns = ['*'])
    {
//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->leftjoin('facebook_ad_image_video', 'facebook_ad.id', '=', 'facebook_ad_image_video.facebook_ad_id')
                    ->leftjoin('facebook_ad_post_owners', 'facebook_ad.post_owner_id', '=', 'facebook_ad_post_owners.id')
                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad.id', '=', 'facebook_ad_meta_data.facebook_ad_id')
                    ->leftjoin('facebook_ad_variants', 'facebook_ad.id', '=', 'facebook_ad_variants.facebook_ad_id')
                    ->select($selectedColumns)
//                    ->toSql();
                    ->get();
//                dd($result);
                $query = getenv("DEBUG_MODE") == 1 ? DB::getQueryLog() : "";
//                $query = (DB::getQueryLog());
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'Ad data found getAdsBySimple.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No Ad data found by getAdsBySimple.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }

            if (getenv("DEBUG_MODE") == 1) {
                $returnData->query = $query;
            }
//            $returnData->query = $query ;
            return json_encode($returnData);
        }
    }

    public function getUserAdsCounts($where)
    {

//        return json_encode($where);
//        DB::enableQueryLog();
        getenv("DEBUG_MODE") == 1 ? DB::enableQueryLog() : "";

        $returnData = new \stdClass();
        $query = "";
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {

                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select("facebook_ad.id")
                        ->get();
//                    ->toSql();

//                return json_encode($result);

                if ($result["data"] == null) {
                    $result["code"] = 400;
                    $result["data"] = null;
                    return  $result;
                }





                $ids_sorted_with_skip_take = array_column($returnData["data"], "facebook_ad.id");
                return json_encode($ids_sorted_with_skip_take);

            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
        }
        return json_encode($returnData);
    }

    public function getPoId($where, $selectedColumns)
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                    ->leftjoin('facebook_ad_meta_data', 'facebook_ad_meta_data.facebook_ad_id', '=', 'facebook_ad.id')
                    ->select($selectedColumns)
                    ->orderBy("facebook_ad.id","desc")
                    ->take(1)
//                    ->toSql();
                    ->get();
//                dd($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    public function getAdLimit($where, $selectedColumns = ['*'])
    {
        $returnData = new \stdClass();
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
//            return json_encode($selectedColumns);
//            return json_encode($where);

            try {
                $result = DB::table($this->table)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($selectedColumns)
//                    ->inRandomOrder()
//                    ->take()
                    ->get();
//                    ->toSql();
//                return json_encode($result);
                $data = (json_decode(json_encode($result), true));
                if (isset($data[0])) {
                    $returnData->code = 200;
                    $returnData->message = 'FacebookAd details.';
                    $returnData->data = $result;
                } else {
                    $returnData->code = 400;
                    $returnData->message = 'No data found.';
                    $returnData->data = null;
                }
            } catch (\Exception $e) {
                $returnData->code = 401;
                $returnData->message = $e->getMessage();
                $returnData->data = null;
            }
            return json_encode($returnData);
        }

    }

    /*Rajamanikandan S
    on 14-08-2019
    using Query builder*/

    public function checkFbId($id){
        try{
            return DB::table($this->table)
                ->where('ad_id',$id)
                ->first();

        }catch(\Exception $e){
            $response['code'] = 401;
            $response['message'] = $e->getMessage();
            $response['data'] = null;
        }

    }

}

