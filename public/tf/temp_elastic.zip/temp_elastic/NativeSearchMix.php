<?php

namespace App\Modules\User\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use App\Search\Searchable;
use Illuminate\Support\Facades\Log;
use Google\Cloud\Translate\TranslateClient;

class NativeSearchMix extends Model
{
    use Searchable;

    protected $table = 'native_search_mix';
    private static $_instance = null;
    /**
     * @var string
     */
    protected $indexConfigurator = NativeSearchMixIndexConfigurator::class;

    public function searchableAs()
    {
        return 'doc';
    }
    /**
     * @var array
     */
    protected $mapping = [
        "properties" => [
            "native_country_only" => [
                "properties" => [
                    "country" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ]
                ]
            ],
            "native_ad" => [
                "properties" => [
                    "id" => ["type" => "long"],
                    "type" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "ad_position" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "ad_sub_position" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "post_date" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss",
//                        "null_value" => "NULL"
                    ],
                    "last_seen" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss",
//                        "null_value" => "NULL"
                    ],
                    "days_running" => ["type" => "long"],
                    "status" => ["type" => "long"],
                    "hits" => ["type" => "long"]
                ]
            ],
            "native_ad_post_owners" => [
                "properties" => [
                    "post_owner_name" => [
                        //"type" => "keyword"//,
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        //"analyzer" => "case_sensitive_exactly"
                        //"index" => "false"
                        /*"fields" => [
                            "case_sensitive" => [
                                "type" => "text",
                                "analyzer" => "case_sensitive"
                            ]
                        ]*/
                    ],
                    "post_owner_name_exactly" => [
                        "type" => "text",
                        "analyzer" => "case_sensitive_exactly"
                    ],
                    "post_owner_name_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "post_owner_name_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "post_owner_name_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "post_owner_name_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "post_owner_lower" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ]
                ]
            ],
            "native_ad_url" => [
                "properties" => [
                    "url" => [
                        "type" => "text",
                        "analyzer" => "case_sensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ]
                ]
            ],
            "native_ad_variants" => [
                "properties" => [
                    "title" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "title_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "title_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "title_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "title_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "title_exactly" => [
                        "type" => "text",
                        "analyzer" => "case_sensitive_exactly_non_limit"
                    ],
                    "text" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "text_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "text_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "text_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "text_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "text_exactly" => [
                        "type" => "text",
                        //"analyzer" => "case_sensitive_exactly"
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 8191
                            ]
                        ]
                    ],
                    "newsfeed_description" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "newsfeed_description_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "newsfeed_description_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "newsfeed_description_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "newsfeed_description_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "newsfeed_description_exactly" => [
                        "type" => "text",
                        //"analyzer" => "case_sensitive_exactly"
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 8191
                            ]
                        ]
                    ],
                    "target_keyword" => [
                        "type" => "keyword"
                    ],
                    "tags" => [
                        "type" => "keyword"
                    ],
                ]
            ],
            "native_ad_meta_data" => [
                "properties" => [
                    "firstSeenOnDesktop" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss",
//                        "null_value" => "NULL"
                    ],
                    "firstSeenOnAndroid" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss"//,
                        //"null_value" => "NULL"
                    ],
                    "firstSeenOnIos" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss"//,
                        //"null_value" => "NULL"
                    ],
                    "destination_url" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 1024
                            ]
                        ]
                    ],
                    "built_with" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "built_with_analytics_tracking" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "lang_detect" => [
                        "type" => "keyword",
                        "ignore_above" => 10
                    ]
                ]
            ]
        ]
    ];

    private $partBody;
    private $from = 0;
    private $size = 10;
    private $sortField = 'native_ad.last_seen';
    private $sortMethod = 'desc';
    private $domain_matched_ids;
    private $post_owner_name;
    private $url;
    private $keyword;
    private $tags;
    private $target_keyword;
    private $call_to_action;
    private $country;
    private $type;
    private $ad_position;
    private $ad_sub_position;
    private $gender;
    private $lower_age_seen;
    private $last_seen;
    private $post_date;
    private $needle;
    private $status;
    private $built_with;
    private $track;
    private $source;
    private $funnel;
    private $affiliate;
    private $searchParams = array();
    private $lang_detect = '';

    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new NativeSearchMix();
        return self::$_instance;
    }

    private function relativeWords($text)
    {
        if(is_array($text)){
            foreach($text as $key => $row)
            {
                $words = explode(" ", $this->escapeWords($row));
                $text[$key] = "(".implode(") AND (",$words).")";
            }
        } else {
            $words = explode(" ",$this->escapeWords($text));
            $text = "(".implode(") AND (",$words).")";
        }
        return $text;
    }

    public function setLangDetect($lang_detect)
    {
        $this->lang_detect = $lang_detect;
    }

    public function getParamLangDetect()
    {

        if (!empty($this->lang_detect)) {
            return [
                "query_string" => [
                    "default_field" => "lang_detect",
                    "query" => "(" . implode(") OR (", $this->lang_detect) . ")"
                ]
            ];
        }
        return '';
    }

    public function lang_detect($search, $search_lang = '')
    {
        $translate = new TranslateClient([
            'key' => env('GOOGLE_TRANSLATE_KEY')
        ]);
        $new_detect_count = 0;
        $not_search_lang_count = 0;
        $datas = array_column($search["hits"]["hits"], "_source");
        //Log::info($datas);
        foreach ($datas as $data) {
            if (!isset($data['lang_detect']) || empty($data['lang_detect'])) {
//                $text = mb_substr($data['native_ad_variants.text'], 0, 300);
                $text = mb_substr($data['native_ad_variants.newsfeed_description'].$data['native_ad_variants.title'].$data['native_ad_variants.text'],0,50);
                $result = $translate->detectLanguage($text);//Log::info($data['native_ad.id']);
                $languageCode = substr($result['languageCode'], 0, 2);
                $this->elasticsearch->updateByQuery([
                    'index' => $this->table,
                    'type' => $this->searchableAs(),
                    'refresh' => true,
                    'body' => [
                        'query' => [
                            'terms' => [
                                "native_ad.id" => [$data['native_ad.id']]
                            ]
                        ],
//                        'script' => "ctx._source['lang_detect'] = '" . $result['languageCode'] . "'"
                        'script' => "ctx._source['lang_detect'] = '".$languageCode."'"
                    ]
                ]);

//                $cd = DB::table("languages")->select("id")->where("iso", strtoupper($result['languageCode']))->first();
                $cd = DB::table("languages")->select("id")->where("iso",strtoupper($languageCode))->first();
                if (isset($cd->id)) {
                    DB::table("native_ad")->where("id", $data['native_ad.id'])->update(["language_id" => $cd->id]);
                }
                $new_detect_count++;
//                if (($search_lang != '') && ($search_lang != $result['languageCode'])) {
                if(($search_lang != '')&&($search_lang != $languageCode)) {
                    $not_search_lang_count++;
                }
            } else if (($search_lang != '') && ($search_lang != $data['lang_detect'])) {
                $not_search_lang_count++;
            }
        }
        return ['new_detect_count' => $new_detect_count, 'not_search_lang_count' => $not_search_lang_count];
    }

    private function escapeWords($text)
    {
        $text = str_replace("!", '\\!', $text);
        $text = str_replace("/", '\\/', $text);
        $text = str_replace("#", '\\#', $text);
        $text = str_replace(":", '\\:', $text);
        $text = str_replace("[", '\\[', $text);
        $text = str_replace("]", '\\]', $text);
        $text = str_replace("(", '\\(', $text);
        $text = str_replace(")", '\\)', $text);
        $text = str_replace("?", '\\?', $text);
        $text = str_replace("&", '\\&', $text);
        $text = str_replace("|", '\\|', $text);
        $text = str_replace('\\', '\\\\', $text);
        $text = str_replace("'", "\\'", $text);
        return $text;
    }

    private function wrapIfNeed($term)
    {
        $pos = strrpos($term, ' ');
        if($pos === false){
            return $term;
        } else {
            return "(".$term.")";
        }
    }

    public function setFrom($from)
    {
        $this->from = $from;
    }

    public function setSize($size)
    {
        $this->size = $size;
    }

    public function setSortField($fieldName)
    {
        $this->sortField = $fieldName;
    }

    public function setSortMethod($methodName)
    {
        if(($methodName == 'desc')||($methodName == 'asc')) {
            $this->sortMethod = $methodName;
        }
    }

    public function setDomainMatchedIds($domain_matched_ids)
    {
        if(is_array($domain_matched_ids)){
            $this->domain_matched_ids = $domain_matched_ids;
        } else {
            $this->domain_matched_ids = [$domain_matched_ids];
        }
    }

    public function setHtmlContent($htmlcontent)
    {
        $this->htmlcontent = trim($htmlcontent);
//        dd($this->mixdata);
    }

    public function getParamHtmlContent()
    {
        if (!empty($this->htmlcontent)) {

            $pos = strrpos($this->htmlcontent, '"');
//            dd($this->htmlcontent);

            if ($pos === false) {

                return [


                    "query_string" => [

                        "query" =>  "*". $this->htmlcontent ."*",
                        "fields" => [
                            "google_ad_html_lander_content.html_whitehat_lander_text",
                            "google_ad_html_lander_content.html_res_blackhat_lander_text",
                            "google_ad_html_lander_content.html_dc_blackhat_lander_text",
                        ]
                    ]

                ];
            }
            else
            {
                return [
                    "query_string" => [
                        'fields' => [
                            "google_ad_html_lander_content.html_whitehat_lander_text",
                            "google_ad_html_lander_content.html_res_blackhat_lander_text",
                            "google_ad_html_lander_content.html_dc_blackhat_lander_text"
//                            "html"
                        ],
                        "query" =>  $this->htmlcontent,
                    ]

                ];

            }
        }
        return '';
    }

    public function getParamDomainMatchedIds()
    {
        if(!empty($this->domain_matched_ids)) {
            return [
                "terms" => [
                    "native_ad.id" => $this->domain_matched_ids
                ]
                /*"query_string" => [
                    "default_field" => "facebook_ad.id",
                    "query" => "(".implode(") OR (",$this->domain_matched_ids).")"
                ]*/
            ];
        }
        return '';
    }

    public function setPostOwnerName($post_owner_name)
    {
        $this->post_owner_name = $post_owner_name;
    }

    public function getParamPostOwnerName()
    {
        if(!empty($this->post_owner_name)) {

            $pos1 = strrpos($this->post_owner_name, '"');
            $pos2 = strrpos($this->post_owner_name, '!');
            if($pos2 != false && $pos1 === false){
                $this->post_owner_name='"'.$this->post_owner_name.'"';
//                dd($this->post_owner_name);
            }

            if($pos1 === false){
                return [
                    "query_string" => [
                        //"default_field" => "native_ad_post_owners.post_owner_name",
                        'fields' => [
                            "native_ad_post_owners.post_owner_name",
                            "native_ad_post_owners.post_owner_name_ru",
                            "native_ad_post_owners.post_owner_name_fr",
                            "native_ad_post_owners.post_owner_name_sp",
                            "native_ad_post_owners.post_owner_name_ge"
                        ],
                        "query" => $this->wrapIfNeed($this->post_owner_name),//.'*',wrapIfNeed
                        "type" => "phrase",//"phrase_prefix",
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false/*,
                        "fuzzy_transpositions" => false,
                        "fuzziness" => 0,
                        "minimum_should_match" => "100%"*/
                    ]
                ];
            } else {
                return [
                    'query_string' => [
                        //"default_field" => "native_ad_post_owners.post_owner_name",
                        "fields" => [
                            "native_ad_post_owners.post_owner_name_exactly"//,
                            //"native_ad_post_owners.post_owner_name_ru",
                            //"native_ad_post_owners.post_owner_name_fr"//,
                            //"native_ad_post_owners.post_owner_name_sp",
                            //"native_ad_post_owners.post_owner_name_ge"
                        ],
                        'query' => $this->post_owner_name,
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false//,
                        //"analyzer" => "case_sensitive"//"case_sensitive_exactly"
                    ]
                    /*'multi_match' => [
                        'query' => $this->post_owner_name,//str_replace('"', '',$this->post_owner_name),
                        'fields' => [
                            "native_ad_post_owners.post_owner_name^2",
                            "native_ad_post_owners.post_owner_name_ru",
                            "native_ad_post_owners.post_owner_name_fr",
                            "native_ad_post_owners.post_owner_name_sp",
                            "native_ad_post_owners.post_owner_name_ge"
                        ],
                        'type' => "phrase",//"best_fields",//
                        //"minimum_should_match" => "100%",
                        "analyzer" => "case_sensitive_exactly",
                        "operator" => "and"
                    ]*/
                ];
            }
        }
        return '';
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }

    public function getParamUrl()
    {
        if(!empty($this->url)) {
            return [
                'query_string' => [
//                    'default_field' => 'native_ad_url.url',
                    'default_field' => 'native_ad_meta_data.destination_url',
                    'query' => '*'.$this->url.'*'
                ]
                /*'match' => [
                    'facebook_ad_url.url' => $this->url
                ]*/
            ];
        }
    }

    public function setTags($tags)
    {
        if(is_array($tags)){
            $this->tags = $tags;
        } else {
            $this->tags = [$tags];
        }
    }

    public function getParamTags(){
        if(!empty($this->tags)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad_variants.tags",
                    "query" => "(".implode(") OR (",$this->tags).")"
                ]
            ];
        }
        return '';
    }

    public function setKeyword($keyword)
    {
        $this->keyword = trim($keyword);
    }

    public function setTargetKeyword($target_keyword)
    {
        if(is_array($target_keyword)){
            $this->target_keyword = $target_keyword;
        } else {
            $this->target_keyword = [$target_keyword];
        }
    }

    public function getParamTargetKeyword(){
        if(!empty($this->target_keyword)) {
            return [
//                "terms" => [
//                    "native_ad_variants.target_keyword" => $this->target_keyword
//                ]
                "query_string" => [
                    "default_field" => "native_ad_variants.target_keyword",
                    "query" => "(".implode(") OR (",$this->target_keyword).")"
                ]
            ];
        }
        return '';
    }

    public function getParamKeyword()
    {
        if(!empty($this->keyword)) {
            $pos = strrpos($this->keyword, '"');
            if($pos === false){
                return [
                    "query_string" => [
                        'fields' => [
                            "native_ad_variants.title",
                            "native_ad_variants.title_ru",
                            "native_ad_variants.title_fr",
                            "native_ad_variants.title_sp",
                            "native_ad_variants.title_ge",
                            "native_ad_variants.text",
                            "native_ad_variants.text_ru",
                            "native_ad_variants.text_fr",
                            "native_ad_variants.text_sp",
                            "native_ad_variants.text_ge",
                            "native_ad_variants.newsfeed_description",
                            "native_ad_variants.newsfeed_description_ru",
                            "native_ad_variants.newsfeed_description_fr",
                            "native_ad_variants.newsfeed_description_sp",
                            "native_ad_variants.newsfeed_description_ge"
                        ],
                        "query" => "(".$this->relativeWords($this->keyword).")",
                        "type" => "phrase",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
            } else {
                return [
                    'query_string' => [
                        'query' => $this->keyword,
                        'fields' => [
                            "native_ad_variants.title_exactly",
                            "native_ad_variants.text_exactly",
                            "native_ad_variants.newsfeed_description_exactly"
                        ],
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
//                return [
//                    'multi_match' => [
//                        'query' => str_replace('"', '', $this->keyword),
//                        'fields' => [
//                            "native_ad_variants.title",
//                            "native_ad_variants.title_ru",
//                            "native_ad_variants.title_fr",
//                            "native_ad_variants.title_sp",
//                            "native_ad_variants.title_ge",
//                            "native_ad_variants.text",
//                            "native_ad_variants.text_ru",
//                            "native_ad_variants.text_fr",
//                            "native_ad_variants.text_sp",
//                            "native_ad_variants.text_ge",
//                            "native_ad_variants.newsfeed_description",
//                            "native_ad_variants.newsfeed_description_ru",
//                            "native_ad_variants.newsfeed_description_fr",
//                            "native_ad_variants.newsfeed_description_sp",
//                            "native_ad_variants.newsfeed_description_ge"
//                        ],
//                        'type' => "phrase"
//                    ]
//                ];
            }
        }
        return '';
    }

    public function setCallToAction($call_to_action)
    {
        if(is_array($call_to_action)){
            $this->call_to_action = $call_to_action;
        } else {
            $this->call_to_action = [$call_to_action];
        }
    }

    public function getParamCallToAction()
    {
        if(!empty($this->call_to_action)) {
            return [
                "query_string" => [
                    "default_field" => "native_call_to_actions.action",
                    "query" => "(".implode(") OR (",$this->relativeWords($this->call_to_action)).")"
                ]
            ];
        }
        return '';
    }

    public function setCountry($country)
    {
        if(is_array($country)){
            $this->country = $country;
        } else {
            $this->country = [$country];
        }
    }

    public function getParamCountry()
    {
        if(!empty($this->country)) {
            return [
                "query_string" => [
                    "default_field" => "native_country_only.country",
                    "query" => "(".implode(") OR (",$this->relativeWords($this->country)).")"
                ]
            ];
        }
        return '';
    }

    public function setAdType($type)
    {
        if(is_array($type)){
            $this->type = $type;
        } else {
            $this->type = [$type];
        }
    }

    public function getParamType()
    {
        if(!empty($this->type)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad.type",
                    "query" => "(".implode(") OR (",$this->type).")"
                ]
            ];
        }
        return '';
    }

    public function setAdPosition($ad_position)
    {
        if(is_array($ad_position)){
            $this->ad_position = $ad_position;
        } else {
            $this->ad_position = [$ad_position];
        }
    }

    public function getParamAdPosition()
    {
        if(!empty($this->ad_position)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad.ad_position",
                    "query" => "(".implode(") OR (",$this->ad_position).")"
                ]
            ];
        }
        return '';
    }
    public function setAdSubPosition($ad_sub_position)
    {
        if(is_array($ad_sub_position)){
            $this->ad_sub_position = $ad_sub_position;
        } else {
            $this->ad_sub_position = [$ad_sub_position];
        }
    }

    public function getParamAdSubPosition()
    {
        if(!empty($this->ad_sub_position)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad.ad_sub_position",
                    "query" => "(".implode(") OR (",$this->ad_sub_position).")"
                ]
            ];
        }
        return '';
    }

    public function setGender($gender)
    {
        if(is_array($gender)){
            $this->gender = $gender;
        } else {
            $this->gender = [$gender];
        }
    }

    public function getParamGender()
    {
        if(!empty($this->gender)) {
            return [
                "query_string" => [
                    "default_field" => "native_user.gender",
                    "query" => "(".implode(") OR (",$this->gender).")"
                ]
            ];
        }
        return '';
    }

    public function setLowerAgeSeen($lower_age_seen)
    {
        if(isset($lower_age_seen['lower_age'])&&isset($lower_age_seen['upper_age'])) {
            $this->lower_age_seen = $lower_age_seen;
        }
    }

    public function getParamLowerAgeSeen()
    {
        if(!empty($this->lower_age_seen)) {
            return [
                'range' => [
                    'native_ad.lower_age_seen' => [
                        'gte'=>$this->lower_age_seen['lower_age'],
                        'lte'=>$this->lower_age_seen['upper_age'],
                    ]
                ]
            ];
        }
        return '';
    }

    public function setLastSeen($last_seen)
    {
        if(isset($last_seen['lower_date'])&&isset($last_seen['upper_date'])) {
            $this->last_seen = $last_seen;
        }
    }

    public function getParamLastSeen()
    {
        if(!empty($this->last_seen)) {
            return [
                'range' => [
                    'native_ad.last_seen' => [
                        'gte'=> $this->last_seen['lower_date'],
                        'lte'=> $this->last_seen['upper_date'],
                        "format" => "yyyy-MM-dd' 'HH:mm:ss"
                    ]
                ]
            ];
        }
        return '';
    }

    public function setPostDate($post_date)
    {
        if(isset($post_date['lower_date'])&&isset($post_date['upper_date'])) {
            $this->post_date = $post_date;
        }
    }

    public function getParamPostDate()
    {
        if(!empty($this->post_date)) {
            return [
                'range' => [
                    'native_ad.post_date' => [
                        'gte'=> $this->post_date['lower_date'],
                        'lte'=> $this->post_date['upper_date'],
                        "format" => "yyyy-MM-dd' 'HH:mm:ss"
                    ]
                ]
            ];
        }
        return '';
    }

    public function setNeedle($needle)
    {
        $this->needle = $needle;
    }

    public function getParamNeedle()
    {
        if(!empty($this->needle)) {
            return [
                'range' => [
                    'native_ad.id' => [
                        'lt'=>$this->needle,
                    ]
                ]
            ];
        }
        return '';
    }

    public function setStatus($status)
    {
        if(is_array($status)){
            $this->status = $status;
        } else {
            $this->status = [$status];
        }
    }

    public function getParamStatus()
    {
        if(!empty($this->status)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad.status",
                    "query" => "(".implode(") OR (",$this->status).")"
                ]
            ];
        }
        return '';
    }

    public function setBuiltWith($built_with)
    {
        $this->built_with = $built_with;
    }

    public function getParamBuiltWith()
    {
        if(!empty($this->built_with)) {
            return [
                'match' => [
                    'native_ad_meta_data.built_with' => $this->built_with
                ]
            ];
        }
    }

    public function setTrack($track)
    {
        if(is_array($track)){
            $this->track = $track;
        } else {
            $this->track = [$track];
        }
    }

    public function getParamTrack()
    {
        if(!empty($this->track)) {
            return [
                "query_string" => [
                    "default_field" => "native_ad_url.url",
                    "query" => "(".implode(") OR (",$this->track).")"
                ]
            ];
        }
        return '';
    }

    public function setSource($source)
    {
        $this->source = $source;
    }

    public function getParamSource()
    {
        if(!empty($this->source)) {
            $tempArr = array();
            if(in_array("desktop",$this->source)){
                $tempArr[] = "native_ad_meta_data.firstSeenOnDesktop";
            }
            if(in_array("ios",$this->source)){
                $tempArr[] = "native_ad_meta_data.firstSeenOnIos";
            }
            if(in_array("android",$this->source)){
                $tempArr[] = "native_ad_meta_data.firstSeenOnAndroid";
            }
            if(count($tempArr) == 1){
                return [
                    "exists" => [
                        "field" => $tempArr[0]
                    ]
                ];
            } else {
                $result = array();
                foreach($tempArr as $val)
                {
                    $result["should"][] = [
                        "exists" => [
                            "field" => $val
                        ]
                    ];
                }
                return [
                    "bool" => $result
                ];
            }
        }
        return '';
    }

    public function setFunnel($funnel)
    {
        $this->funnel = $funnel;
    }

    public function getParamFunnel()
    {
        if(!empty($this->funnel)) {
            if($this->funnel == '%') {
                return [
                    'exists' => [
                        'field' => 'native_ad_meta_data.built_with_analytics_tracking'
                    ]
                ];
            } else {
                return [
                    'match' => [
                        'native_ad_meta_data.built_with_analytics_tracking' => $this->funnel
                    ]
                ];
            }
        }
    }

    public function setAffiliate($affiliate)
    {
        $this->affiliate = $affiliate;
    }

    public function getParamAffiliate()
    {
        if(!empty($this->affiliate)) {
            return [
                'query_string' => [
                    'default_field' => 'native_ad_url.url',
//                    'query' => '*'.$this->affiliate.'*'
                    'query' => '"'.$this->affiliate.'"'
                ]
                /*'match' => [
                    'facebook_ad_url.url' => $this->affiliate //facebook_ad_meta_data.destination_url
                ]*/
            ];
        }
    }

    public function buildQuerySearch()
    {
        $fields = ["domain_matched_ids","post_owner_name","url","keyword","tags","target_keyword","country",
            "type","ad_position","ad_sub_position","last_seen","post_date","htmlcontent",
            "needle","status","built_with","track","source","funnel","affiliate"];//"call_to_action","gender","lower_age_seen"
        $is_created = false;
        $temp = array();
        while (!$is_created){
            if(isset($fields[0])){
                $field = array_shift($fields);
                $field = 'getParam'.studly_case($field);
                if(!empty($this->$field())){
                    $temp[] = $this->$field();
                }
            } else {
                $is_created = true;
            }
        }
        $this->partBody = $this->formatBody($temp);

        if ($this->lang_detect != '') {
            $this->partBody["bool"]["should"] = $this->getParamLangDetect();
            $this->partBody["bool"]["minimum_should_match"] = 1;
        }
    }

    public function formatBody($temp)
    {
        if(isset($temp[1])){
            return [
                'bool' => [
                    "must" => $temp[0],
                    'filter' => $this->formatBody(array_slice($temp, 1))
                ]
            ];
        } else {
            return [
                'bool' => [
                    "must" => $temp[0]
                ]
            ];
        }
    }

    public function getCompileParams()
    {
        return $this->searchParams;
    }

    public function buildParams()
    {
        $this->buildQuerySearch();
        $this->searchParams['index'] = $this->table;
        $this->searchParams['type'] = $this->searchableAs();
        $this->searchParams['body']['from'] = $this->from;
        $this->searchParams['body']['size'] = $this->size;
        $this->searchParams['body']['sort'] = [$this->sortField => $this->sortMethod];
        $this->searchParams['body']['query'] = $this->partBody;
    }

    public function run()
    {
        $this->buildParams();
        $search = $this->elasticsearch->search($this->getCompileParams());
        Log::info($this->getCompileParams());

//        $result_detect = $this->lang_detect($search, $this->lang_detect);
//        /********** OR recursive ***********/
//        if ($result_detect['not_search_lang_count'] > 0) {
//            $search = $this->elasticsearch->search($this->getCompileParams());
//            $result_detect = $this->lang_detect($search, $this->lang_detect);
//        }
        return $this->viewResult($search);
    }
}
