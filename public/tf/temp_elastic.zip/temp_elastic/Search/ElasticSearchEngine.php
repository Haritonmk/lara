<?php

namespace App\Search;
use ScoutElastic\ElasticEngine;
use Illuminate\Database\Eloquent\Collection;
use ScoutElastic\Builders\SearchBuilder;
use Illuminate\Support\Facades\Log;
use Laravel\Scout\Builder;
use ScoutElastic\Payloads\TypePayload;
use stdClass;
/*use Illuminate\Support\Facades\Artisan;

use Laravel\Scout\Engines\Engine;
use ScoutElastic\Facades\ElasticClient;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use ScoutElastic\Indexers\IndexerInterface;

*/

class ElasticSearchEngine extends ElasticEngine { //Engine {
        
    /**
     * @inheritdoc
     */
    public function mapIds($results)
    {
        return array_pluck($results['hits']['hits'], '_source.id');
    }

    /**
     * @inheritdoc
     */
    public function map($results, $model)
    {
        if ($this->getTotalCount($results) == 0) {
            return Collection::make();
        }

        $primaryKey = $model->getKeyName();

        $columns = array_get($results, '_payload.body._source');

        if (is_null($columns)) {
            $columns = ['*'];
        } else {
            $columns[] = $primaryKey;
        }

        $ids = $this->mapIds($results);

        $builder = $model->usesSoftDelete() ? $model->withTrashed() : $model->newQuery();

        $models = $builder
            ->whereIn($primaryKey, $ids)
            ->get($columns)
            ->keyBy($primaryKey);

        return Collection::make($results['hits']['hits'])
            ->map(function ($hit) use ($models) {
                $id = $hit['_source']['id'];

                if (isset($models[$id])) {
                    $model = $models[$id];

                    if (isset($hit['highlight'])) {
                        $model->highlight = new Highlight($hit['highlight']);
                    }

                    return $model;
                }
            })
            ->filter()
            ->values();
    }
    
    /**
     * @param Builder $builder
     * @param array $options
     * @return array
     */
    public function buildSearchQueryPayloadCollection(Builder $builder, array $options = [])
    {
        $payloadCollection = collect();

        if (($builder instanceof SearchBuilder)||($builder instanceof ElasticSearchBuilder)) {
            $searchRules = $builder->rules ?: $builder->model->getSearchRules();

            foreach ($searchRules as $rule) {
                $payload = new TypePayload($builder->model);

                if (is_callable($rule)) {
                    $payload->setIfNotEmpty('body.query.bool', call_user_func($rule, $builder));
                } else {
                    /** @var ElasticSearchRule $ruleEntity */
                   $ruleEntity = new $rule($builder);

                    if ($ruleEntity->isApplicable()) {
                        $payload->setIfNotEmpty('body.query.bool', $ruleEntity->buildQueryPayload());
                        $payload->setIfNotEmpty('body.highlight', $ruleEntity->buildHighlightPayload());
                        $payload->setIfNotEmpty('body.query', $ruleEntity->buildFreeQueryPayload());
                    } else {
                        continue;
                    }
                }

                $payloadCollection->push($payload);
            }
        } else {
            $payload = (new TypePayload($builder->model))
                ->setIfNotEmpty('body.query.bool.must.match_all', new stdClass());

            $payloadCollection->push($payload);
        }

        return $payloadCollection->map(function (TypePayload $payload) use ($builder, $options) {
            $payload
                ->setIfNotEmpty('body._source', $builder->select)
                ->setIfNotEmpty('body.collapse.field', $builder->collapse)
                ->setIfNotEmpty('body.sort', $builder->orders)
                ->setIfNotEmpty('body.explain', $options['explain'] ?? null)
                ->setIfNotEmpty('body.profile', $options['profile'] ?? null)
                ->setIfNotNull('body.from', $builder->offset)
                ->setIfNotNull('body.size', $builder->limit);


            foreach ($builder->wheres as $clause => $filters) {
                $clauseKey = 'body.query.bool.filter.bool.' . $clause;

                $clauseValue = array_merge(
                    $payload->get($clauseKey, []),
                    $filters
                );

                $payload->setIfNotEmpty($clauseKey, $clauseValue);
            }

            return $payload->get();
        });
    }
}
