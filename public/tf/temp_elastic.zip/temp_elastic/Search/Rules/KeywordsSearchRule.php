<?php

namespace App\Search\Rules;

use App\Search\SearchRule;

class KeywordsSearchRule extends SearchRule
{
    /**
     * @inheritdoc
     */
    public function buildHighlightPayload()
    {
        
    }

    /**
     * @inheritdoc
     */
    public function buildQueryPayload()
    {
        
    }
    
    public function buildFreeQueryPayload()
    {
        return [
            'multi_match' => [
                'query' => $this->builder->query,
                'fields' => ["title","text","newsfeed_description"],
                'type' => "phrase"
            ]
        ];
    }
}