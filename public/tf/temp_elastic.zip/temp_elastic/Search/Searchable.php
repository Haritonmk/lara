<?php

namespace App\Search;
use Elasticsearch\Client;
use Elasticsearch\ClientBuilder;
//use Illuminate\Database\Eloquent\Model;
//use Laravel\Scout\Builder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
//use ScoutElastic\Builders\FilterBuilder;
//use ScoutElastic\Builders\SearchBuilder;
//use ScoutElastic\SearchRule;
use ScoutElastic\Searchable as ElasticSearchable;
//use Laravel\Scout\Searchable as ScoutSearchable;
//use Illuminate\Database\Eloquent\Builder;
//use Illuminate\Database\Query\Builder as QueryBuilder;
use DB;

trait Searchable
{
    use ElasticSearchable;
    /*use ScoutSearchable {
        ScoutSearchable::bootSearchable as bootScoutSearchable;
    }*/

    protected $elasticsearch;
    protected static $elasticsearchst;
    protected $params;
    protected $select;
    private static $isSearchableTraitBooted = false;
    private $extraModelsUpdate = array("facebook_ad","facebook_call_to_actions",
        "country_only","facebook_users","facebook_ad_meta_data","facebook_ad_post_owners",
        "facebook_ad_variants","facebook_ad_url");
    public static function bootSearchable()
    {
        //if (config('services.search.enabled')) {
        //static::observe(ElasticsearchObserver::class);
        //}
        /*self::$elasticsearchst = ClientBuilder::create()
                ->setHosts(config('services.search.hosts'))
                ->build();*/
        //return (new static)->
        if (self::$isSearchableTraitBooted) {
            return;
        }

        self::bootScoutSearchable();

        self::$isSearchableTraitBooted = true;
    }
    public function __construct()
    {
        $this->elasticsearch = ClientBuilder::create()
            ->setHosts(config('services.search.hosts'))
            ->build();
        $this->setIndex($this->getSearchIndex());
        $this->setType($this->getSearchType());
        $this->setSelect(['*']);
    }

    public function setSelect($select)
    {
        $this->select = $select;
    }

    public function getSelect()
    {
        return $this->select;
    }

    public function setIndex($index)
    {
        $this->params['index'] = $index;
    }

    public function getSearchIndex()
    {
//        dd(strtolower($this->getTable()));
        return strtolower($this->getTable());
    }

    public function setType($type)
    {
        $this->params['type'] = $type;
    }

    public function getSearchType()
    {
        /*if (property_exists($this, 'useSearchType')) {
            return $this->useSearchType;
        }*/

        return 'doc';//$this->getTable();
    }

    public function toSearchArray()
    {
        return $this->toArray();
    }

    /**
     * @return array
     */
    public function getSearchRules()
    {
        return isset($this->searchRules) && count($this->searchRules) > 0 ?
            $this->searchRules : [SearchRule::class];
    }

    /**
     * @param $query
     * @param null $callback
     * @return ElasticFilterBuilder|ElasticSearchBuilder
     */
    public static function search($query, $callback = null)
    {
        //$softDelete = config('scout.soft_delete', false);
        $softDelete = false;

        if ($query == '*') {
            return new ElasticFilterBuilder(new static, $callback, $softDelete);
        } else {
            return new ElasticSearchBuilder(new static, $query, $callback, $softDelete);
        }
    }

    /**
     * @param array $query
     * @return array
     */
    public static function searchRaw(array $query)
    {
        $model = new static();

        return $model->searchableUsing()
            ->searchRaw($model, $query);
    }

    public function save(array $options = [])
    {
        $query = $this->newQueryWithoutScopes();
//        dd($query);
        if ($this->fireModelEvent('saving') === false) {
            return false;
        }

        if ($this->exists) {
            $saved = $this->isDirty() ?
                $this->performUpdate($query) : true;

//            dd($saved);

            if ($saved) {
//                dd($saved);
                $this->elasticsearch->delete([
                    'index' => $this->getSearchIndex(),
                    'type' => $this->getSearchType(),
                    'refresh' => true,
                    'id' => $this->searchID($this->attributes[$this->primaryKey]),//$this->attributes['id']
                ]);
//                 $result = $this->elasticsearch->update([
//                    'index' => $this->getSearchIndex(),
//                    'type' => $this->getSearchType(),
//                    'id' => $this->searchID($this->attributes['id']),//!!!
//                    'body' => $this->toSearchArray(),
//                ]);
//                dd($result);
            }
        }
        else {

            $saved = $this->performInsert($query);

            if (! $this->getConnectionName() &&
                $connection = $query->getConnection()) {
                $this->setConnection($connection->getName());
            }
        }

        if ($saved) {
//            dd($saved);
            $body = $this->toSearchArray();
//            dd($body);
            if($this->hasMapping()&&(count($this->getAttributes())!=count($this->getMappingFieldsList()))){
                $findModel = $this->find($this->attributes[$this->primaryKey]);//$this->id
                $body = $findModel->toSearchArray();
            }

            $this->elasticsearch->index([
                'index' => $this->getSearchIndex(),
                'type' => $this->getSearchType(),
                'refresh' => true,
                'body' => $body,
            ]);

            if($this->exists&&in_array($this->table, $this->extraModelsUpdate)){
                $this->updateSearchMix();
            }
            $this->finishSave($options);
        }

        return $saved;
    }

    public function insertGetId(array $values, $sequence = null)
    {
        $query = $this->newQueryWithoutScopes();
//        dd($query);
        //$values = $this->cleanBindingsVal($values);

        $id = $query->insertGetId($values, $keyName = $this->getKeyName());

        $this->setForceAttributes($values);
        $this->setAttribute($keyName, $id);

        $params = [
            'index' => $this->getSearchIndex(),
            'type' => $this->getSearchType(),
            'body' => $this->toSearchArray(),
        ];
        $params['body'][$this->primaryKey] = $id;
        $this->elasticsearch->index($params);
        return $id;
    }

    /**
     * Update the model in the database.
     *
     * @param  array  $attributes
     * @param  array  $options
     * @return bool
     */
    public function update(array $attributes = [], array $options = [])
    {
        if (! $this->exists) {
            return false;
        }

        $this->setForceAttributes($attributes);

        return $this->save($options);
    }

    public function delete()
    {

        if (is_null($this->getKeyName())) {
            throw new Exception('No primary key defined on model.');
        }

        // If the model doesn't exist, there is nothing to delete so we'll just return
        // immediately and not do anything else. Otherwise, we will continue with a
        // deletion process on the model, firing the proper events, and so forth.
        if (! $this->exists) {
            return;
        }

        if ($this->fireModelEvent('deleting') === false) {
            return false;
        }

        // Here, we'll touch the owning models, verifying these timestamps get updated
        // for the models. This will allow any caching to get broken on the parents
        // by the timestamp. Then we will go ahead and delete the model instance.
        $this->touchOwners();

        $this->elasticsearch->delete([
            'index' => $this->getSearchIndex(),
            'type' => $this->getSearchType(),
            'id' => $this->searchID($this->attributes[$this->primaryKey]),
        ]);

        $this->performDeleteOnModel();

        // Once the model has been deleted, we will fire off the deleted event so that
        // the developers may hook into post-delete operations. We will then return
        // a boolean true as the delete is presumably successful on the database.
        $this->fireModelEvent('deleted', false);

        return true;
    }


    public function insert(array $values)
    {
        if (empty($values)) {
            return true;
        }
        $query = $this->newQueryWithoutScopes();
        if(!is_array(reset($values))){
            $result = $this->insertOneRow($values, $query);
        } else {
            foreach ($values as $key => $value) {
                $result = $this->insertOneRow($value, $query);
            }
        }

        return $result;
    }

    private function insertOneRow($values, $query)
    {
        if(isset($values[$this->primaryKey])){
            $result = $query->insert($values);
        } else {
            $id = $query->insertGetId($values, $keyName = $this->getKeyName());
            $values[$this->primaryKey] = $id;
            $result = true;
        }
        if($result){
            $this->elasticsearch->index([
                'index' => $this->getSearchIndex(),
                'type' => $this->getSearchType(),
                'body' => $values,
            ]);
        }
        return $result;
    }

    /**
     * Remove all of the expressions from a list of bindings.
     *
     * @param  array  $bindings
     * @return array
     */
    protected function cleanBindingsVal(array $bindings)
    {
        return array_values(array_filter($bindings, function ($binding) {
            return ! $binding instanceof Expression;
        }));
    }

    public function setWhereRaw($rawQuery,$bindParams)
    {
        $this->params['body'] = array('query' => array('term' => array($this->primaryKey => '1')));
    }

    protected function searchID($id)
    {
//        dd(11);
        $result = $this->elasticsearch->search([
            'index' => $this->getSearchIndex(),
            'type' => $this->getSearchType(),
            'body' => array('query' => array('term' => array($this->primaryKey => $id))),
        ]);
//        dd($result["hits"]["hits"][0]['_id']);
        return $result["hits"]["hits"][0]['_id'];
    }

    protected function viewResult($result)
    {
        $data = array_column($result["hits"]["hits"], "_source");
        if(empty($this->getSelect())||$this->getSelect()[0] == "*"){
            return $data;
        } else {
            $fields = $this->getSelect();
            /*$collection = collect($data);
            $filtered = $collection->filter(function ($value, $key) use ($fields) {
                return in_array($key, $fields);
            });
            return json_encode($filtered->all());*/
            $dataNew = array();
            foreach ($fields as $field) {
                $dataNew[$field] = array_column($data, $field);
            }
            return json_encode($dataNew);
        }
    }

    protected function setArray($obj)
    {
        return json_decode(json_encode($obj),true);
    }

    protected function setForceAttributes($attributes)
    {
        foreach ($attributes as $key => $value) {
            $this->setAttribute($key, $value);
        }
    }

    protected function hasMapping()
    {
//        dd(11);
        return (isset($this->mapping)&&isset($this->mapping["properties"]));
    }

    public function getMappingFieldsList()
    {
        if($this->hasMapping()){
            list($keys, $values) = array_divide($this->mapping["properties"]);
            return $keys;
        } else {
            return [];
        }
    }

    public function getFieldSendToQuery($fieldName, $queryName, $data)
    {
        $ids_sorted_with_skip_take = array_column($data, $fieldName);
        $clause4DeveloperId = implode(',', array_fill(0, count($ids_sorted_with_skip_take), '?'));
        $query = ' '.$queryName.' IN (' . $clause4DeveloperId . ') ';
        return ['query' => $query, 'fields' => $ids_sorted_with_skip_take];
    }

    private function updateSearchMix()
    {
        $idFA = array();
        if($this->table == "facebook_ad"){
            $idFA = [$this->attributes['id']];
        } else {
            $idFA = $this->getIDFA();
        }
        $scripts = $this->formatScriptQuery();
        foreach ($scripts as $script) {
            $this->elasticsearch->updateByQuery([
                'index' => 'search_mix',
//                'index' => 'facebook_task',
                'type' => $this->getSearchType(),
                'refresh' => true,
                'body' => [
                    'query' => [
                        'terms' => [
                            "facebook_ad.id" => $idFA
                        ]
                    ],
                    'script' => $script
                ]
            ]);
        }
    }

    private function getIDFA()
    {
        $result = array();
        switch ($this->table)
        {
            case "facebook_call_to_actions":
                $modelsFA = DB::table("facebook_ad")->where('call_to_action_id',$this->attributes['id'])->get();
                break;
            case "country_only":
                $modelsFA = DB::table("facebook_ad")->where('country_only_id',$this->attributes['id'])->get();
                break;
            case "facebook_users":
                $modelsFA = DB::table("facebook_ad")->where('discoverer_user_id',$this->attributes['id'])->get();
                break;
            case "facebook_ad_meta_data":
                $modelsFA = DB::table("facebook_ad")->where('id',$this->attributes['facebook_ad_id'])->get();//!!!
                break;
            case "facebook_ad_post_owners":
                $modelsFA = DB::table("facebook_ad")->where('post_owner_id',$this->attributes['id'])->get();
                break;
            case "facebook_ad_variants":
                $modelsFA = DB::table("facebook_ad")->where('default_variant_id',$this->attributes['id'])->get();
                break;
            case "facebook_ad_url":
                $modelsFA = DB::table("facebook_ad")->where('id',$this->attributes['facebook_ad_id'])->get();//!!!
                break;
        }
        foreach ($modelsFA as $modelFA) {
            $result[] = $modelFA->id;
        }
        return $result;
    }

    private function formatScriptQuery()
    {
        $script = "";
        $scripts = array();
        $ar = array(
            'facebook_ad' => ['status','post_date','last_seen','lower_age_seen',
                'days_running','likes','comments','shares','ad_position','type','hits'],
            'facebook_users' => ['Gender'],
            'country_only' => ['country'],
            'facebook_call_to_actions' => ['action'],
            'facebook_ad_variants' => ['title|ru,fr,sp,ge,exactly','text|ru,fr,sp,ge,exactly','newsfeed_description|ru,fr,sp,ge,exactly','tags'],
            'facebook_ad_url' => ['url'],
            'facebook_ad_post_owners' => ['post_owner_name|ru,fr,sp,ge,exactly','post_owner_lower','verified','page_created_date'],
            'facebook_ad_meta_data' => ['destination_url','firstSeenOnDesktop',
                'built_with','built_with_analytics_tracking',
                'firstSeenOnAndroid','firstSeenOnIos']
        );
        foreach ($ar[$this->table] as $value) {
            $pos = strpos($value, "|");
            $tempValue = '';
            if($pos !== false){
                $temp = explode("|",$value);
                $value = $temp[0];
                $langs = explode(",",$temp[1]);
            }
            if(isset($this->attributes[$value])){
                $script.= "ctx._source['".$this->table.".".$value."'] = ";
                if($this->hasMapping()&&isset($this->mapping["properties"][$value])){
                    if(($this->mapping["properties"][$value]["type"] == "long")||($this->mapping["properties"][$value]["type"] == "integer")){
                        $script.= $this->attributes[$value].";";
                        if($pos !== false){
                            $tempValue = $this->attributes[$value].";";
                        }
                    } else {
                        $script.= "'".$this->attributes[$value]."';";
                        if($pos !== false){
                            $tempValue = "'".$this->attributes[$value]."';";
                        }
                    }
                } else {
                    $script.= "'".$this->attributes[$value]."';";
                    if($pos !== false){
                        $tempValue = "'".$this->attributes[$value]."';";
                    }
                }
            }
            if(strlen($script) > 300){
                $scripts[] = $script;
                $script = "";
            }
            if($pos !== false){
                foreach ($langs as $lang) {
                    $script.= "ctx._source['".$this->table.".".$value."_".$lang."'] = ".$tempValue;
                }
            }
        }
        if(strlen($script) > 0){
            $scripts[] = $script;
        }
        return $scripts;
    }
}
