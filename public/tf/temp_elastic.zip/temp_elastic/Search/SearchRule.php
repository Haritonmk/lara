<?php

namespace App\Search;

use App\Search\ElasticSearchBuilder;

class SearchRule
{
    /**
     * @var SearchBuilder
     */
    protected $builder;

    /**
     * @param SearchBuilder $builder
     */
    public function __construct(ElasticSearchBuilder $builder)
    {
        $this->builder = $builder;
    }

    /**
     * @return bool
     */
    public function isApplicable()
    {
        return true;
    }

    /**
     * @return array|null
     */
    public function buildHighlightPayload()
    {
        return null;
    }

    /**
     * @return array
     */
    public function buildQueryPayload()
    {
        return [
            'must' => [
                'query_string' => [
                    'query' => $this->builder->query
                ]
            ]
        ];
    }
    
    /**
     * @return array
     */
    public function buildFreeQueryPayload()
    {
        return null;
    }
}