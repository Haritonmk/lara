<?php

namespace App\Search;

use ScoutElastic\Builders\FilterBuilder;

class ElasticFilterBuilder extends FilterBuilder
{
    /**
     * @var array
     */
    public $select = [];

    /**
     * @param mixed $fields
     * @return $this
     */
    public function select($fields)
    {
        $this->select = array_merge(
            $this->select,
            array_wrap($fields)
        );
        if(!in_array('id', $this->select)){
            $this->select[] = 'id';
        }

        return $this;
    }
}
