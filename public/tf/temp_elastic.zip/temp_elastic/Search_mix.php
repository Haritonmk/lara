<?php

namespace App\Modules\User\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use App\Search\Searchable;
use Illuminate\Support\Facades\Log;
use Google\Cloud\Translate\TranslateClient;

class Search_mix extends Model
{
    use Searchable;

    protected $table = 'search_mix';
    private static $_instance = null;
    /**
     * @var string
     */
    protected $indexConfigurator = SearchMixIndexConfigurator::class;

    public function searchableAs()
    {
        return 'doc';
    }

    /**
     * @var array
     */
    protected $mapping = [
        "properties" => [
            "country_only" => [
                "properties" => [
                    "country" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ]
                ]
            ],
            "facebook_ad" => [
                "properties" => [
                    "ad_position" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "id" => ["type" => "long"],
                    "last_seen" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss",
//                        "null_value" => "NULL"
                    ],
                    "lower_age_seen" => ["type" => "long"],
                    "post_date" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss",
//                        "null_value" => "NULL"
                    ],
                    "status" => ["type" => "long"],
                    "type" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "days_running" => ["type" => "long"],
                    "likes" => ["type" => "long"],
                    "comments" => ["type" => "long"],
                    "shares" => ["type" => "long"],
                    "hits" => ["type" => "long"],
                    "platform" => ["type" => "long"],
                    "discoverer_user_id" => ["type" => "long"]
                ]
            ],
            "facebook_ad_post_owners" => [
                "properties" => [
                    "post_owner_name" => [
                        //"type" => "keyword"//,
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        //"analyzer" => "case_sensitive_exactly"
                        //"index" => "false"
                        /*"fields" => [
                            "case_sensitive" => [
                                "type" => "text",
                                "analyzer" => "case_sensitive"
                            ]
                        ]*/
                    ],
                    "post_owner_name_exactly" => [
                        "type" => "text",
                        "analyzer" => "case_sensitive_exactly"
                    ],
                    "post_owner_name_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "post_owner_name_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "post_owner_name_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "post_owner_name_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "post_owner_lower" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "page_created_date" => [//!!!
                        "type" => "date",
                        "format" => "yyyy-MM-dd ",
                    ],
                    "verified" => [//!!!
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                    ]
                ]
            ],
            "facebook_ad_url" => [
                "properties" => [
                    "url" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ]
                ]
            ],
            "facebook_ad_variants" => [
                "properties" => [
                    "newsfeed_description" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "newsfeed_description_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "newsfeed_description_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "newsfeed_description_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "newsfeed_description_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "newsfeed_description_exactly" => [
                        "type" => "text",
                        //"analyzer" => "case_sensitive_exactly"
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 8191
                            ]
                        ]
                    ],
                    "text" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "text_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "text_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "text_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "text_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "text_exactly" => [
                        "type" => "text",
                        //"analyzer" => "case_sensitive_exactly"
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 8191
                            ]
                        ]
                    ],
                    "title" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"
                        /*"fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]*/
                    ],
                    "title_ru" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ru"
                    ],
                    "title_fr" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_fr"
                    ],
                    "title_sp" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_sp"
                    ],
                    "title_ge" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive_ge"
                    ],
                    "title_exactly" => [
                        "type" => "text",
                        "analyzer" => "case_sensitive_exactly_non_limit"
                    ],
                    "tags" => [
                        "type" => "keyword"
                    ],
                ]
            ],
            "facebook_call_to_actions" => [
                "properties" => [
                    "action" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ]
                ]
            ],
            "facebook_users" => [
                "properties" => [
                    "Gender" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ]
                ]
            ],
            "facebook_ad_meta_data" => [
                "properties" => [
                    "destination_url" => [
                        "type" => "text",
                        "analyzer" => "case_insensitive"


                    ],
                    "firstSeenOnDesktop" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss"//,
                        //"null_value" => "NULL"
                    ],
                    "built_with" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "built_with_analytics_tracking" => [
                        "type" => "text",
                        "fields" => [
                            "keyword" => [
                                "type" => "keyword",
                                "ignore_above" => 256
                            ]
                        ]
                    ],
                    "firstSeenOnAndroid" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss"//,
                        //"null_value" => "NULL"
                    ],
                    "firstSeenOnIos" => [
                        "type" => "date",
                        "format" => "yyyy-MM-dd HH:mm:ss"//,
                        //"null_value" => "NULL"
                    ]
                ]
            ],
            "lang_detect" => [
                "type" => "keyword",
                "ignore_above" => 10
            ],
            "facebook_comments" => [
                "properties" => [
                    "comment_data" => [
                        "type" => "text"
                    ]
                ]
            ],
            "html" => [
                "type" => "text",
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 8191
                    ]
                ]
            ],

            "mixdata" => [
                "type" => "text",
                //"analyzer" => "case_sensitive_exactly"
                "fields" => [
                    "keyword" => [
                        "type" => "keyword",
                        "ignore_above" => 8191
                    ]
                ]
            ],

            "facebook_ad_html_lander_content" => [
                "properties" => [

                    "html_whitehat_lander_text" => [
                                "type" => "text"
            ],
                    "html_res_blackhat_lander_text" => [
                                "type" => "text"
            ],
                    "html_dc_blackhat_lander_text" => [
                                "type" => "text"
            ]
        ]
                ]
            ],

//        "html_whitehat_lander_test" => [
//                                "type" => "text"
//            ],
//                    "html_res_blackhat_lander_test" => [
//                                "type" => "text"
//            ],
//                    "html_dc_blackhat_lander_test" => [
//                                "type" => "text"
//            ]
    ];

    private $partBody;
    private $from = 0;
    private $size = 970000;
    private $sortField = 'facebook_ad.last_seen';
    private $sortMethod = 'desc';
    private $domain_matched_ids;
    private $post_owner_name;
    private $url;
    private $keyword;
    private $tags;
    private $call_to_action;
    private $country;
    private $type;
    private $ad_position;
    private $gender;
    private $lower_age_seen;
    private $last_seen;
    private $post_date;
    private $needle;
    private $status;
    private $built_with;
    private $track;
    private $source;
    private $funnel;
    private $affiliate;
    private $searchParams = array();
    private $lang_detect = '';
    private $likesdata = '';
    private $commentsdata = '';
    private $sharesdata = '';
    private $html = '';
    private $comment_data = '';
    private $mixdata = '';
    private $htmlcontent = '';
    /*Aishwarya */  private $ltLastSeen ='';



    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new Search_mix();
        return self::$_instance;
    }

    private function relativeWords($text)
    {
        if (is_array($text)) {
            foreach ($text as $key => $row) {
                $words = explode(" ", $this->escapeWords($row));
                $text[$key] = "(" . implode(") AND (", $words) . ")";
            }
        } else {
            $words = explode(" ", $this->escapeWords($text));
            $text = "(" . implode(") AND (", $words) . ")";
        }
        return $text;
    }

    private function escapeWords($text)
    {
        $text = str_replace("!", '\\!', $text);
        $text = str_replace("/", '\\/', $text);
        $text = str_replace("#", '\\#', $text);
        $text = str_replace(":", '\\:', $text);
        $text = str_replace("[", '\\[', $text);
        $text = str_replace("]", '\\]', $text);
        $text = str_replace("(", '\\(', $text);
        $text = str_replace(")", '\\)', $text);
        $text = str_replace("?", '\\?', $text);
        $text = str_replace("&", '\\&', $text);
        $text = str_replace("|", '\\|', $text);
        $text = str_replace('\\', '\\\\', $text);
        $text = str_replace("'", "\\'", $text);
        $text = str_replace(".", '\\.', $text);
        return $text;
    }

    private function wrapIfNeed($term)
    {

        $pos = strrpos($term, ' ');
        if ($pos === false) {
            return $term;
        } else {
            return "(" . $term . ")";
        }
    }

    public function setFrom($from)
    {
        $this->from = $from;
    }

    public function setSize($size)
    {
        $this->size = $size;
    }

    public function setSortField($fieldName)
    {
//        dd($fieldName);
        $this->sortField = $fieldName;
    }

    public function setSortMethod($methodName)
    {
        if (($methodName == 'desc') || ($methodName == 'asc')) {
            $this->sortMethod = $methodName;
        }
    }

//    public function setFilterField($lastseenFilter){
//        $this->ltLastSeen =$lastseenFilter;
//    }

    public function setDomainMatchedIds($domain_matched_ids)
    {
        if (is_array($domain_matched_ids)) {
            $this->domain_matched_ids = $domain_matched_ids;
        } else {
            $this->domain_matched_ids = [$domain_matched_ids];
        }
    }

    public function getParamDomainMatchedIds()
    {
        if (!empty($this->domain_matched_ids)) {
            return [
                "terms" => [
                    "facebook_ad.id" => $this->domain_matched_ids
                ]
                /*"query_string" => [
                    "default_field" => "facebook_ad.id",
                    "query" => "(".implode(") OR (",$this->domain_matched_ids).")"
                ]*/
            ];
        }
        return '';
    }

    public function setPostOwnerName($post_owner_name)
    {
//        dd($post_owner_name);
        $this->post_owner_name = $post_owner_name;
    }

    public function getParamPostOwnerName()
    {
        if (!empty($this->post_owner_name)) {
            $pos = strrpos($this->post_owner_name, '"');
            if ($pos === false) {
//                dd($this->wrapIfNeed($this->post_owner_name));
                return [
                    "query_string" => [
                        //"default_field" => "facebook_ad_post_owners.post_owner_name",
                        'fields' => [
                            "facebook_ad_post_owners.post_owner_name",
                            "facebook_ad_post_owners.post_owner_name_ru",
                            "facebook_ad_post_owners.post_owner_name_fr",
                            "facebook_ad_post_owners.post_owner_name_sp",
                            "facebook_ad_post_owners.post_owner_name_ge"
                        ],
                        "query" => $this->wrapIfNeed($this->post_owner_name),//.'*',wrapIfNeed
//                        "query" => $this->post_owner_name,//.'*',wrapIfNeed
                        "type" => "phrase",//"phrase_prefix",
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false/*,
                        "fuzzy_transpositions" => false,
                        "fuzziness" => 0,
                        "minimum_should_match" => "100%"*/
                    ]
                ];
            } else {
                return [
                    'query_string' => [
                        //"default_field" => "facebook_ad_post_owners.post_owner_name",
                        "fields" => [
                            "facebook_ad_post_owners.post_owner_name_exactly"//,
                            //"facebook_ad_post_owners.post_owner_name_ru",
                            //"facebook_ad_post_owners.post_owner_name_fr"//,
                            //"facebook_ad_post_owners.post_owner_name_sp",
                            //"facebook_ad_post_owners.post_owner_name_ge"
                        ],
                        'query' => $this->post_owner_name,
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false//,
                        //"analyzer" => "case_sensitive"//"case_sensitive_exactly"
                    ]
                    /*'multi_match' => [
                        'query' => $this->post_owner_name,//str_replace('"', '',$this->post_owner_name),
                        'fields' => [
                            "facebook_ad_post_owners.post_owner_name^2",
                            "facebook_ad_post_owners.post_owner_name_ru",
                            "facebook_ad_post_owners.post_owner_name_fr",
                            "facebook_ad_post_owners.post_owner_name_sp",
                            "facebook_ad_post_owners.post_owner_name_ge"
                        ],
                        'type' => "phrase",//"best_fields",//
                        //"minimum_should_match" => "100%",
                        "analyzer" => "case_sensitive_exactly",
                        "operator" => "and"
                    ]*/
                ];
            }
        }
        return '';
    }

    public function setVerified($verified)
    {
        $this->verified = $verified;
//        dd($this->verified);
    }

    public function getParamVerified()
    {
//        dd("verified".$this->verified);
        if (isset($this->verified) && $this->verified!=="NA") {
            return [
                'match' => [
                    'facebook_ad_post_owners.verified' => $this->verified
                ]
            ];
        }
        return '';
    }

//    public function setMixdata($mixdata)
//    {
//        if (is_array($mixdata)) {
//            $this->mixdata = $mixdata;
//        } else {
//            $this->mixdata = [$mixdata];
//        }
////        dd($this->verified);
//    }

//    public function getParamMixData()
//    {
////        dd("verified".$this->verified);
//        if (!empty($this->mixdata)) {
//            $pos = strrpos($this->mixdata, '"');
//
//            if ($pos === false) {
//                return [
//
//                        "wildcard" => [     "mixdata" => [      "value" => "*".$this->mixdata."*"     ]    ]   ,
//
//                ];
//            }else{
//                return [
//                    'query_string' => [
//                        'query' => $this->mixdata,
//                        'fields' => [
//                            "mixdata"
//                        ],
//                        "default_operator" => "AND",
//                        "auto_generate_synonyms_phrase_query" => false
//                    ]
//                ];
//
//            }
//        }
//    }


    public function setUrl($url)
    {
//        dd($url);
        $this->url = trim($url);
    }

    public function getParamUrl()
    {

        if (!empty($this->url)) {
//            dd($this->url);
            $pos = strrpos($this->url, '"');
            if ($pos === false) {
                return [
                    'query_string' => [
                        'fields' => [
                            'facebook_ad_meta_data.destination_url'
                        ],//'facebook_ad_url.url',
                        "query" => "(" . $this->relativeWords($this->url) . ")",
                        "type" => "phrase",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                    /*'match' => [
                        'facebook_ad_url.url' => $this->url
                    ]*/

//                    "wildcard" => [     "facebook_ad_meta_data.destination_url" => [      "value" => "*".$this->url."*"     ]    ]
                ];

            }
        }
    }

    public function setTags($tags)
    {
        if (is_array($tags)) {
            $this->tags = $tags;
        } else {
            $this->tags = [$tags];
        }
    }

    public function getParamTags()
    {
        if (!empty($this->tags)) {
            return [
                "query_string" => [
                    "fields" => [
                        "facebook_ad_variants.tags"
                    ],
                    "query" => "(" . implode(") OR (", $this->tags) . ")"
                ]
            ];
        }
        return '';
    }
    public function setCommentdata($comment_data)
    {
        if (is_array($comment_data)) {
            $this->comment_data = $comment_data;
        } else {
            $this->comment_data = $comment_data;
        }
    }

    public function setMixdata($mixdata)
    {
        $this->mixdata = trim($mixdata);
//        dd($this->mixdata);
    }

    public function getParamMixdata()
    {
        if (!empty($this->mixdata)) {
//            dd($this->mixdata);
            $pos = strrpos($this->mixdata, '"');

            if ($pos === false) {
                return [

//                    "wildcard" => [     "mixdata" => [      "value" => "*".$this->mixdata."*"     ]    ]

                    "query_string" => [
                        'fields' => [
                            "mixdata"
//                            "html"
                        ],
                        "query" => "(" . $this->relativeWords($this->mixdata) . ")",
                        "type" => "phrase",
                        "auto_generate_synonyms_phrase_query" => false
                    ]

                ];
            }else{
                return [
                    'query_string' => [
                        'query' => $this->mixdata,
                        'fields' => [
                            "mixdata"
                        ],
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];

            }
        }
        return '';
    }

    public function setHtmlContent($htmlcontent)
    {
        $this->htmlcontent = trim($htmlcontent);
//        dd($this->mixdata);
    }

    public function getParamHtmlContent()
    {
        if (!empty($this->htmlcontent)) {

            $pos = strrpos($this->htmlcontent, '"');
//            dd($this->htmlcontent);

            if ($pos === false) {

                return [


                        "query_string" => [

                            "query" =>  "*". $this->htmlcontent ."*",
                            "fields" => [
                                "facebook_ad_html_lander_content.html_whitehat_lander_test",
                                "facebook_ad_html_lander_content.html_res_blackhat_lander_test",
                                "facebook_ad_html_lander_content.html_dc_blackhat_lander_test",
                                "facebook_ad_html_lander_content.html_whitehat_lander_text",
                                "facebook_ad_html_lander_content.html_res_blackhat_lander_text",
                                "facebook_ad_html_lander_content.html_dc_blackhat_lander_text",
                            ]
                        ]



//                    "query_string" => [
//                        'fields' => [
//
//                            "facebook_ad_html_lander_content.html_whitehat_lander_test",
//                            "facebook_ad_html_lander_content.html_res_blackhat_lander_test",
//                            "facebook_ad_html_lander_content.html_dc_blackhat_lander_test",
//                            "facebook_ad_html_lander_content.html_whitehat_lander_text",
//                            "facebook_ad_html_lander_content.html_res_blackhat_lander_text",
//                            "facebook_ad_html_lander_content.html_dc_blackhat_lander_text",
//
////                            "html"
//                        ],
//                        "query" => "(" . $this->relativeWords($this->htmlcontent) . ")",
//                        "type" => "phrase",
//                        "auto_generate_synonyms_phrase_query" => false
//                    ]

                ];
            }
            else
            {
                return [
                    "query_string" => [
                        'fields' => [

                            "facebook_ad_html_lander_content.html_whitehat_lander_test",
                            "facebook_ad_html_lander_content.html_res_blackhat_lander_test",
                            "facebook_ad_html_lander_content.html_dc_blackhat_lander_test",
                                "facebook_ad_html_lander_content.html_whitehat_lander_text",
                            "facebook_ad_html_lander_content.html_res_blackhat_lander_text",
                            "facebook_ad_html_lander_content.html_dc_blackhat_lander_text"
//                            "html"
                        ],
                        "query" =>  $this->htmlcontent,
                    ]

                ];

            }
        }
        return '';
    }

    public function getParamCommentdata()
    {
        if (!empty($this->comment_data)) {
            $pos = strrpos($this->comment_data, '"');

            if ($pos === false) {
                return [

//                    "wildcard" => [     "facebook_comments.comment_data" => [      "value" => "*".$this->comment_data."*"     ]    ]   ,
                    "query_string" => [

                        "query" =>  "*". $this->comment_data ."*",
                        "fields" => [
                            "facebook_comments.comment_data",
                            "comment_data"
                        ]
                    ]
                ];
            }else{
                return [
                    'query_string' => [
                        'query' => $this->comment_data,
                        'fields' => [
                            "facebook_comments.comment_data"
                        ],
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];

            }
        }
        return '';
    }

    public function setPageCreation($page_created_date)
    {
        if (isset($page_created_date['lower_date']) && isset($page_created_date['upper_date'])) {
            $this->page_created_date = $page_created_date;
        }
    }

    public function getParamPageCreatedDate()
    {
        if (!empty($this->page_created_date)) {
            return [
                'range' => [
                    'facebook_ad_post_owners.page_created_date' => [
                        'gte' => $this->page_created_date['lower_date'],
                        'lte' => $this->page_created_date['upper_date'],
                        "format" => "yyyy-MM-dd' 'HH:mm:ss"

                    ]
                ]
            ];
        }
        return '';
    }

    public function setKeyword($keyword)
    {
        $this->keyword = trim($keyword);
    }

    public function getParamKeyword()
    {
        if (!empty($this->keyword)) {
            $pos = strrpos($this->keyword, '"');
            if ($pos === false) {
                return [
                    "query_string" => [
                        'fields' => [
                            "facebook_ad_variants.title",
                            "facebook_ad_variants.title_ru",
                            "facebook_ad_variants.title_fr",
                            "facebook_ad_variants.title_sp",
                            "facebook_ad_variants.title_ge",
                            "facebook_ad_variants.text",
                            "facebook_ad_variants.text_ru",
                            "facebook_ad_variants.text_fr",
                            "facebook_ad_variants.text_sp",
                            "facebook_ad_variants.text_ge",
                            "facebook_ad_variants.newsfeed_description",
                            "facebook_ad_variants.newsfeed_description_ru",
                            "facebook_ad_variants.newsfeed_description_fr",
                            "facebook_ad_variants.newsfeed_description_sp",
                            "facebook_ad_variants.newsfeed_description_ge"
//                            "html"
                        ],
                        "query" => "(" . $this->relativeWords($this->keyword) . ")",
                        "type" => "phrase",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
            } else {
                return [
                    'query_string' => [
                        'query' => $this->keyword,
                        'fields' => [
                            "facebook_ad_variants.title_exactly",
                            "facebook_ad_variants.text_exactly",
                            "facebook_ad_variants.newsfeed_description_exactly"
                        ],
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
//                return [
//                    'multi_match' => [
//                        'query' => str_replace('"', '', $this->keyword),
//                        'fields' => [
//                            "facebook_ad_variants.title",
//                            "facebook_ad_variants.title_ru",
//                            "facebook_ad_variants.title_fr",
//                            "facebook_ad_variants.title_sp",
//                            "facebook_ad_variants.title_ge",
//                            "facebook_ad_variants.text",
//                            "facebook_ad_variants.text_ru",
//                            "facebook_ad_variants.text_fr",
//                            "facebook_ad_variants.text_sp",
//                            "facebook_ad_variants.text_ge",
//                            "facebook_ad_variants.newsfeed_description",
//                            "facebook_ad_variants.newsfeed_description_ru",
//                            "facebook_ad_variants.newsfeed_description_fr",
//                            "facebook_ad_variants.newsfeed_description_sp",
//                            "facebook_ad_variants.newsfeed_description_ge"
//                        ],
//                        'type' => "phrase"
//                    ]
//                ];
            }
        }
        return '';
    }

    public function setHtml($html)
    {
        $this->html = trim($html);
    }

    public function getParamHtml()
    {
        if (!empty($this->html)) {
            $pos = strrpos($this->html, '"');
            if ($pos === false) {
                return [
                    "query_string" => [
                        'fields' => [

                            "html"
                        ],
                        "query" => "(" . $this->relativeWords($this->html) . ")",
                        "type" => "phrase",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
            } else {
                return [
                    'query_string' => [
                        'query' => $this->html,
                        'fields' => [
                            "html"
                        ],
                        "default_operator" => "AND",
                        "auto_generate_synonyms_phrase_query" => false
                    ]
                ];
//                return [
//                    'multi_match' => [
//                        'query' => str_replace('"', '', $this->keyword),
//                        'fields' => [
//                            "facebook_ad_variants.title",
//                            "facebook_ad_variants.title_ru",
//                            "facebook_ad_variants.title_fr",
//                            "facebook_ad_variants.title_sp",
//                            "facebook_ad_variants.title_ge",
//                            "facebook_ad_variants.text",
//                            "facebook_ad_variants.text_ru",
//                            "facebook_ad_variants.text_fr",
//                            "facebook_ad_variants.text_sp",
//                            "facebook_ad_variants.text_ge",
//                            "facebook_ad_variants.newsfeed_description",
//                            "facebook_ad_variants.newsfeed_description_ru",
//                            "facebook_ad_variants.newsfeed_description_fr",
//                            "facebook_ad_variants.newsfeed_description_sp",
//                            "facebook_ad_variants.newsfeed_description_ge"
//                        ],
//                        'type' => "phrase"
//                    ]
//                ];
            }
        }
        return '';
    }



    public function setCallToAction($call_to_action)
    {
        if (is_array($call_to_action)) {
            $this->call_to_action = $call_to_action;
        } else {
            $this->call_to_action = [$call_to_action];
        }
    }


    public function getParamCallToAction()
    {
        if (!empty($this->call_to_action)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_call_to_actions.action",
                    "query" => "(" . implode(") OR (", $this->relativeWords($this->call_to_action)) . ")"
                ]
            ];
        }
        return '';
    }



    public function setCountry($country)
    {
        if (is_array($country)) {
            $this->country = $country;
        } else {
            $this->country = [$country];
        }
    }

    public function getParamCountry()
    {
        if (!empty($this->country)) {
            return [
                "query_string" => [
                    "default_field" => "country_only.country",
                    "query" => "(" . implode(") OR (", $this->relativeWords($this->country)) . ")"
                ]
            ];
        }
        return '';
    }

    public function setAdType($type)
    {
        if (is_array($type)) {
            $this->type = $type;
        } else {
            $this->type = [$type];
        }
    }

    public function getParamType()
    {
        if (!empty($this->type)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_ad.type",
                    "query" => "(" . implode(") OR (", $this->type) . ")"
                ]
            ];
        }
        return '';
    }



    public function setAdPosition($ad_position)
    {
        if (is_array($ad_position)) {
            $this->ad_position = $ad_position;
        } else {
            $this->ad_position = [$ad_position];
        }
    }

    public function getParamAdPosition()
    {
        if (!empty($this->ad_position)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_ad.ad_position",
                    "query" => "(" . implode(") OR (", $this->ad_position) . ")"
                ]
            ];
        }
        return '';
    }

    public function setGender($gender)
    {
        if (is_array($gender)) {
            $this->gender = $gender;
        } else {
            $this->gender = [$gender];
        }
    }

    public function getParamGender()
    {
        if (!empty($this->gender)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_users.Gender",
                    "query" => "(" . implode(") OR (", $this->gender) . ")"
                ]
            ];
        }
        return '';
    }

    public function setLowerAgeSeen($lower_age_seen)
    {
        if (isset($lower_age_seen['lower_age']) && isset($lower_age_seen['upper_age'])) {
            $this->lower_age_seen = $lower_age_seen;
        }
    }

    public function getParamLowerAgeSeen()
    {
        if (!empty($this->lower_age_seen)) {
            return [
                'range' => [
                    'facebook_ad.lower_age_seen' => [
                        'gte' => $this->lower_age_seen['lower_age'],
                        'lte' => $this->lower_age_seen['upper_age'],
                    ]
                ]
            ];
        }
        return '';
    }

    public function setLastSeen($last_seen)
    {
        if (isset($last_seen['lower_date']) && isset($last_seen['upper_date'])) {
            $this->last_seen = $last_seen;
        }
    }

    public function getParamLastSeen()
    {

        if (!empty($this->last_seen)) {

            return [
                'range' => [
                    'facebook_ad.last_seen' => [
                        'gte' => $this->last_seen['lower_date'],
                        'lte' => $this->last_seen['upper_date'],
                        "format" => "yyyy-MM-dd' 'HH:mm:ss"
                    ]
                ]
            ];
        }

        return '';
    }

    public function setPostDate($post_date)
    {
        if (isset($post_date['lower_date']) && isset($post_date['upper_date'])) {
            $this->post_date = $post_date;
        }
    }

    public function getParamPostDate()
    {
        if (!empty($this->post_date)) {
            return [
                'range' => [
                    'facebook_ad.post_date' => [
                        'gte' => $this->post_date['lower_date'],
                        'lte' => $this->post_date['upper_date'],
                        "format" => "yyyy-MM-dd' 'HH:mm:ss"
                    ]
                ]
            ];
        }
        return '';
    }

    public function setNeedle($needle)
    {
        $this->needle = $needle;
    }

    public function getParamNeedle()
    {
        if (!empty($this->needle)) {
//            dd($this->needle);
            return [
                'range' => [
                    'facebook_ad.last_seen' => [
                        'lt' => $this->needle,
                    ]
                ]
            ];
        }
        return '';
    }

    public function setLikes($likesdata)
    {

        if (is_array($likesdata)) {
            $this->likesdata = $likesdata;
        } else {
            $this->likesdata = [$likesdata];
        }
    }

    public function getParamLikes()
    {
        if (!empty($this->likesdata)) {
            return [
                'range' => [
                    'facebook_ad.likes' => [
                        'gte' => intval($this->likesdata[0]),
                        'lte' => intval($this->likesdata[1])
                    ]
                ]
            ];
        }
        return '';
    }

    public function setComments($commentsdata)
    {

        if (is_array($commentsdata)) {
            $this->commentsdata = $commentsdata;
        } else {
            $this->commentsdata = [$commentsdata];
        }
    }

    public function getParamComments()
    {
        if (!empty($this->commentsdata)) {
            return [
                'range' => [
                    'facebook_ad.comments' => [
                        'gte' => intval($this->commentsdata[0]),
                        'lte' => intval($this->commentsdata[1])
                    ]
                ]
            ];
        }
        return '';
    }

    public function setShares($sharesdata)
    {

        if (is_array($sharesdata)) {
            $this->sharesdata = $sharesdata;
        } else {
            $this->sharesdata = [$sharesdata];
        }
    }

    public function getParamShares()
    {
        if (!empty($this->sharesdata)) {
            return [
                'range' => [
                    'facebook_ad.shares' => [
                        'gte' => intval($this->sharesdata[0]),
                        'lte' => intval($this->sharesdata[1])
                    ]
                ]
            ];
        }
        return '';
    }
    public function setStatus($status)
    {
        if (is_array($status)) {
            $this->status = $status;
        } else {
            $this->status = [$status];
        }
    }

    public function getParamStatus()
    {
        if (!empty($this->status)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_ad.status",
                    "query" => "(" . implode(") OR (", $this->status) . ")"
                ]
            ];
        }
        return '';
    }

    public function setBuiltWith($built_with)
    {
        $this->built_with = $built_with;
    }

    public function getParamBuiltWith()
    {
        if (!empty($this->built_with)) {
            return [
                'match' => [
                    'facebook_ad_meta_data.built_with' => $this->built_with
                ]
            ];
        }
    }

    public function setPlatform($platform)
    {
        if (is_array($platform)) {
            $this->platform = $platform;
        } else {
            $this->platform = [$platform];
        }
    }

    public function getParamPlatform()
    {

        if (!empty($this->platform)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_ad.platform",
                    "query" => "(" . implode(") OR (", $this->platform) . ")"
                ]
            ];
        }
        return '';
    }

    public function setDiscovereruserid($discoverer_user_id)
    {
        $this->discoverer_user_id = $discoverer_user_id;
    }

    public function getParamDiscovereruserid()
    {
        if (!empty($this->discoverer_user_id)) {
            return [
                'match' => [
                    'facebook_ad.discoverer_user_id' => $this->discoverer_user_id
                ]
            ];
        }
    }

    public function setTrack($track)
    {
        if (is_array($track)) {
            $this->track = $track;
        } else {
            $this->track = [$track];
        }
    }

    public function getParamTrack()
    {
        if (!empty($this->track)) {
            return [
                "query_string" => [
                    "default_field" => "facebook_ad_url.url",
                    "query" => "(" . implode(") OR (", $this->track) . ")"
                ]
            ];
        }
        return '';
    }

    public function setSource($source)
    {
        $this->source = $source;
    }

    public function getParamSource()
    {
        if (!empty($this->source)) {
            $tempArr = array();
            if (in_array("desktop", $this->source)) {
                $tempArr[] = "facebook_ad_meta_data.firstSeenOnDesktop";
            }
            if (in_array("ios", $this->source)) {
                $tempArr[] = "facebook_ad_meta_data.firstSeenOnIos";
            }
            if (in_array("android", $this->source)) {
                $tempArr[] = "facebook_ad_meta_data.firstSeenOnAndroid";
            }
            if (count($tempArr) == 1) {
                return [
                    "exists" => [
                        "field" => $tempArr[0]
                    ]
                ];
            } else {
                $result = array();
                foreach ($tempArr as $val) {
                    $result["should"][] = [
                        "exists" => [
                            "field" => $val
                        ]
                    ];
                }
                return [
                    "bool" => $result
                ];
            }
        }
        return '';
    }

    public function setFunnel($funnel)
    {
        $this->funnel = str_replace(" ", "", $funnel);
    }

    public function getParamFunnel()
    {
        if (!empty($this->funnel)) {
            if ($this->funnel == '%') {
                return [
                    'exists' => [
                        'field' => 'facebook_ad_meta_data.built_with_analytics_tracking'
                    ]
                ];
            } else {
                return [
                    'match' => [
                        'facebook_ad_meta_data.built_with_analytics_tracking' => $this->funnel
                    ]
                ];
            }
        }
    }

    public function setAffiliate($affiliate)
    {
        $this->affiliate = $affiliate;
    }

    public function getParamAffiliate()
    {
        if (!empty($this->affiliate)) {
            return [
                'query_string' => [
                    'default_field' => 'facebook_ad_url.url',
                    'query' => '"' . $this->affiliate . '"'
                ]
                /*'match' => [
                    'facebook_ad_url.url' => $this->affiliate //facebook_ad_meta_data.destination_url
                ]*/
            ];
        }
    }

    public function setLangDetect($lang_detect)
    {
        $this->lang_detect = $lang_detect;
    }

    public function getParamLangDetect()
    {

        if (!empty($this->lang_detect)) {
            return [
                "query_string" => [
                    "default_field" => "lang_detect",
                    "query" => "(" . implode(") OR (", $this->lang_detect) . ")"
                ]
            ];
        }
        return '';
    }

//    public function getParamLangDetect()
//    {
//
//        if ($this->lang_detect != '') {
//            return [
//                //"should" => [
//                [
//                    "query_string" => [
//                        "default_field" => "lang_detect",
//                        "query" => $this->lang_detect
//                    ]
//                ], +[
//                    "bool" => [
//                        "must_not" => [
//                            "exists" => [
//                                "field" => "lang_detect"
//                            ]
//                        ]
//                    ]
//                ]
//                //],
//                //"minimum_should_match" => 1
//            ];
//        }
//    }


    public function buildQuerySearch()
    {
        $fields = ["domain_matched_ids", "post_owner_name","discovereruserid","platform" ,"url", "keyword", "tags", "call_to_action", "country",
            "type", "ad_position", "gender", "lower_age_seen", "last_seen", "post_date","page_created_date" ,"verified","mixdata","htmlcontent",
            "needle", "status", "built_with", "track", "source", "funnel", "affiliate","likes","comments","shares","html","commentdata"];
        $is_created = false;
        $temp = array();
        while (!$is_created) {
            if (isset($fields[0])) {
                $field = array_shift($fields);
                $field = 'getParam' . studly_case($field);
                if (!empty($this->$field())) {
                    $temp[] = $this->$field();
                }
            } else {
                $is_created = true;
            }
        }
        $this->partBody = $this->formatBody($temp);

        if ($this->lang_detect != '') {
            $this->partBody["bool"]["should"] = $this->getParamLangDetect();
            $this->partBody["bool"]["minimum_should_match"] = 1;
        }

    }

    public function formatBody($temp)
    {
        if (isset($temp[1])) {
            return [
                'bool' => [
                    "must" => $temp[0],
                    'filter' => $this->formatBody(array_slice($temp, 1))
                ]
            ];
        } else {
            return [
                'bool' => [
                    "must" => $temp[0]
                ]
            ];
        }
    }

    public function lang_detect($search, $search_lang = '')
    {
        $translate = new TranslateClient([
            'key' => env('GOOGLE_TRANSLATE_KEY')
        ]);
        $new_detect_count = 0;
        $not_search_lang_count = 0;
        $datas = array_column($search["hits"]["hits"], "_source");
        //Log::info($datas);
        foreach ($datas as $data) {
            if (!isset($data['lang_detect']) || empty($data['lang_detect'])) {
//                $text = mb_substr($data['facebook_ad_variants.text'], 0, 300);
                $text = mb_substr($data['facebook_ad_variants.newsfeed_description'] . $data['facebook_ad_variants.title'] . $data['facebook_ad_variants.text'], 0, 50);
                $result = $translate->detectLanguage($text);//Log::info($data['facebook_ad.id']);
                $languageCode = substr($result['languageCode'], 0, 2);
                $this->elasticsearch->updateByQuery([
                    'index' => $this->table,
                    'type' => $this->searchableAs(),
                    'refresh' => true,
                    'body' => [
                        'query' => [
                            'terms' => [
                                "facebook_ad.id" => [$data['facebook_ad.id']]
                            ]
                        ],
//                        'script' => "ctx._source['lang_detect'] = '" . $result['languageCode'] . "'"
                        'script' => "ctx._source['lang_detect'] = '".$languageCode."'"
                    ]
                ]);

//                $cd = DB::table("languages")->select("id")->where("iso", strtoupper($result['languageCode']))->first();
                $cd = DB::table("languages")->select("id")->where("iso",strtoupper($languageCode))->first();
                if (isset($cd->id)) {
                    DB::table("facebook_ad")->where("id", $data['facebook_ad.id'])->update(["language_id" => $cd->id]);
                }
                $new_detect_count++;
//                if (($search_lang != '') && ($search_lang != $result['languageCode'])) {
                if(($search_lang != '')&&($search_lang != $languageCode)) {
                    $not_search_lang_count++;
                }
            } else if (($search_lang != '') && ($search_lang != $data['lang_detect'])) {
                $not_search_lang_count++;
            }
        }
        return ['new_detect_count' => $new_detect_count, 'not_search_lang_count' => $not_search_lang_count];
    }

    public function getCompileParams()
    {
        return $this->searchParams;
    }

    public function buildParams()
    {
        $this->buildQuerySearch();
        $this->searchParams['index'] = $this->table;
        $this->searchParams['type'] = $this->searchableAs();
        $this->searchParams['body']['from'] = $this->from;
        $this->searchParams['body']['size'] = $this->size;
        $this->searchParams['body']['sort'] = [$this->sortField => $this->sortMethod];
        $this->searchParams['body']['query'] = $this->partBody;
        Log::info($this->getCompileParams($this->searchParams));
//        dd($this->searchParams);
    }

    public function run()
    {
        $this->buildParams();
//        Log::info($this->buildParams());
        $search = $this->elasticsearch->search($this->getCompileParams());
//        Log::info($this->getCompileParams());
//        $result_detect = $this->lang_detect($search, $this->lang_detect);
        /********** OR recursive ***********/
//        if ($result_detect['not_search_lang_count'] > 0) {
//            $search = $this->elasticsearch->search($this->getCompileParams());
//            $result_detect = $this->lang_detect($search, $this->lang_detect);
//        }
        return $this->viewResult($search);
    }
}
